-- ============================================
-- 采购管理系统 - 数据库初始化脚本
-- ============================================

-- 创建数据库
CREATE DATABASE IF NOT EXISTS pms_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pms_db;

-- ============================================
-- 1. 供应商表
-- ============================================
DROP TABLE IF EXISTS purchase_detail;
DROP TABLE IF EXISTS purchase_main;
DROP TABLE IF EXISTS product;
DROP TABLE IF EXISTS supplier;
DROP TABLE IF EXISTS member;
DROP TABLE IF EXISTS employee;

CREATE TABLE supplier (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    supplier_no VARCHAR(50) NOT NULL UNIQUE COMMENT '供应商编号',
    name VARCHAR(100) NOT NULL COMMENT '供应商名称',
    short_name VARCHAR(50) COMMENT '供应商简称',
    address VARCHAR(200) COMMENT '地址',
    phone VARCHAR(20) COMMENT '公司电话',
    email VARCHAR(100) COMMENT '邮件',
    contact_person VARCHAR(50) COMMENT '联系人',
    contact_phone VARCHAR(20) COMMENT '联系人电话',
    remark VARCHAR(500) COMMENT '备注',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='供应商表';

-- ============================================
-- 2. 员工表
-- ============================================
CREATE TABLE employee (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    employee_no VARCHAR(50) NOT NULL UNIQUE COMMENT '员工编号',
    name VARCHAR(50) NOT NULL COMMENT '员工姓名',
    password VARCHAR(200) NOT NULL COMMENT '员工密码(BCrypt)',
    level INT NOT NULL DEFAULT 2 COMMENT '员工级别 1=管理员 2=普通用户',
    phone VARCHAR(20) COMMENT '员工电话',
    salary DECIMAL(10,2) COMMENT '员工工资',
    remark VARCHAR(500) COMMENT '备注',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='员工表';

-- ============================================
-- 3. 商品表
-- ============================================
CREATE TABLE product (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    product_no VARCHAR(50) NOT NULL UNIQUE COMMENT '商品编号',
    name VARCHAR(100) NOT NULL COMMENT '商品名称',
    price DECIMAL(10,2) NOT NULL COMMENT '商品单价',
    supplier_id BIGINT COMMENT '供应商编号',
    description VARCHAR(500) COMMENT '商品简介',
    remark VARCHAR(500) COMMENT '备注',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    FOREIGN KEY (supplier_id) REFERENCES supplier(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品表';

-- ============================================
-- 4. 会员表
-- ============================================
CREATE TABLE member (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    member_no VARCHAR(50) NOT NULL UNIQUE COMMENT '会员编号',
    name VARCHAR(50) NOT NULL COMMENT '会员姓名',
    phone VARCHAR(20) COMMENT '电话',
    address VARCHAR(200) COMMENT '地址',
    email VARCHAR(100) COMMENT '邮件',
    remark VARCHAR(500) COMMENT '备注',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员表';

-- ============================================
-- 5. 采购主表
-- ============================================
CREATE TABLE purchase_main (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    purchase_no VARCHAR(50) NOT NULL UNIQUE COMMENT '采购清单号',
    employee_id BIGINT NOT NULL COMMENT '员工编号',
    total_quantity INT DEFAULT 0 COMMENT '采购数量',
    total_price DECIMAL(12,2) DEFAULT 0.00 COMMENT '采购总价',
    purchase_time DATETIME COMMENT '采购时间',
    remark VARCHAR(500) COMMENT '备注',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    FOREIGN KEY (employee_id) REFERENCES employee(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='采购主表';

-- ============================================
-- 6. 采购明细表
-- ============================================
CREATE TABLE purchase_detail (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    detail_no VARCHAR(50) COMMENT '采购明细号',
    purchase_main_id BIGINT NOT NULL COMMENT '采购清单号',
    product_id BIGINT NOT NULL COMMENT '商品编号',
    quantity INT NOT NULL COMMENT '采购数量',
    unit_price DECIMAL(10,2) COMMENT '商品单价',
    total_price DECIMAL(12,2) COMMENT '商品总价',
    remark VARCHAR(500) COMMENT '备注',
    FOREIGN KEY (purchase_main_id) REFERENCES purchase_main(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES product(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='采购明细表';

-- ============================================
-- 初始数据
-- ============================================

-- 管理员账户 (密码: 123456, BCrypt加密)
-- 普通用户账户 (密码: 123456, BCrypt加密)
INSERT INTO employee (employee_no, name, password, level, phone, salary, remark) VALUES
('admin', '系统管理员', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', 1, '13800000001', 8000.00, '系统管理员账户'),
('user001', '普通用户', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', 2, '13800000002', 5000.00, '普通用户账户'),
('EMP001', '张三', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', 2, '13800000003', 6000.00, '采购部员工');

-- 供应商数据
INSERT INTO supplier (supplier_no, name, short_name, address, phone, email, contact_person, contact_phone, remark) VALUES
('SUP001', '华为技术有限公司', '华为', '深圳市龙岗区坂田华为基地', '0755-28780808', 'sales@huawei.com', '李明', '13900010001', '通信设备供应商'),
('SUP002', '联想集团有限公司', '联想', '北京市海淀区上地信息产业基地', '010-58868888', 'sales@lenovo.com', '王强', '13900010002', '计算机设备供应商'),
('SUP003', '阿里巴巴集团', '阿里', '杭州市余杭区文一西路969号', '0571-85022088', 'sales@alibaba.com', '赵敏', '13900010003', '电商平台服务商');

-- 商品数据
INSERT INTO product (product_no, name, price, supplier_id, description, remark) VALUES
('P001', '华为MateBook X Pro', 7999.00, 1, '14英寸轻薄笔记本', '热销款'),
('P002', '华为Mate 60 Pro', 6999.00, 1, '旗舰智能手机', '新品'),
('P003', '联想ThinkPad X1 Carbon', 9999.00, 2, '14英寸商务笔记本', '高端款'),
('P004', '联想拯救者Y9000P', 8999.00, 2, '16英寸游戏笔记本', '游戏本'),
('P005', '阿里云服务器ECS', 3600.00, 3, '云服务器标准版', '按年订阅');

-- 会员数据
INSERT INTO member (member_no, name, phone, address, email, remark) VALUES
('M001', '张三', '13800010001', '北京市朝阳区', 'zhangsan@email.com', 'VIP会员'),
('M002', '李四', '13800010002', '上海市浦东新区', 'lisi@email.com', '普通会员'),
('M003', '王五', '13800010003', '广州市天河区', 'wangwu@email.com', 'VIP会员');

-- 采购主表数据
INSERT INTO purchase_main (purchase_no, employee_id, total_quantity, total_price, purchase_time, remark) VALUES
('PO202401001', 1, 10, 79990.00, '2024-01-15 10:30:00', '第一批采购'),
('PO202401002', 1, 5, 44995.00, '2024-01-20 14:00:00', '第二批采购'),
('PO202402001', 3, 8, 63992.00, '2024-02-10 09:00:00', '张三采购单');

-- 采购明细数据
INSERT INTO purchase_detail (detail_no, purchase_main_id, product_id, quantity, unit_price, total_price, remark) VALUES
('D001', 1, 1, 10, 7999.00, 79990.00, '笔记本采购明细'),
('D002', 2, 1, 2, 7999.00, 15998.00, '笔记本'),
('D003', 2, 3, 3, 9999.00, 29997.00, 'ThinkPad'),
('D004', 3, 4, 8, 8999.00, 71992.00, '拯救者采购');
