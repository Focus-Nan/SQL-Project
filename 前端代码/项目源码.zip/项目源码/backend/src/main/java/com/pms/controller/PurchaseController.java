package com.pms.controller;

import com.pms.common.Result;
import com.pms.entity.PurchaseDetail;
import com.pms.entity.PurchaseMain;
import com.pms.repository.ProductRepository;
import com.pms.repository.PurchaseMainRepository;
import com.pms.service.PurchaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@RestController
@RequestMapping("/api/purchases")
public class PurchaseController {

    @Autowired
    private PurchaseService purchaseService;

    @Autowired
    private PurchaseMainRepository purchaseMainRepository;

    @Autowired
    private ProductRepository productRepository;

    // ============ Purchase Main ============

    @GetMapping("/main")
    public Result<List<PurchaseMain>> listMain(@RequestParam(required = false) Long employeeId) {
        return Result.success(purchaseService.listMain(employeeId));
    }

    @GetMapping("/main/{id}")
    public Result<PurchaseMain> getMainById(@PathVariable Long id) {
        return Result.success(purchaseService.getMainById(id));
    }

    @PostMapping("/main")
    public Result<PurchaseMain> createMain(@RequestBody PurchaseMain main, HttpServletRequest request) {
        // All logged-in users can create purchases
        return Result.success(purchaseService.createMain(main));
    }

    @PutMapping("/main/{id}")
    public Result<PurchaseMain> updateMain(@PathVariable Long id, @RequestBody PurchaseMain main, HttpServletRequest request) {
        checkAdmin(request);
        return Result.success(purchaseService.updateMain(id, main));
    }

    @DeleteMapping("/main/{id}")
    public Result<?> deleteMain(@PathVariable Long id, HttpServletRequest request) {
        purchaseService.deleteMain(id);
        return Result.success();
    }

    // ============ Purchase Detail ============

    @GetMapping("/detail")
    public Result<List<PurchaseDetail>> listDetail(@RequestParam(required = false) Long mainId) {
        if (mainId != null) {
            return Result.success(purchaseService.listDetailByMainId(mainId));
        }
        return Result.success(purchaseService.listAllDetails());
    }

    @GetMapping("/detail/{id}")
    public Result<PurchaseDetail> getDetailById(@PathVariable Long id) {
        return Result.success(purchaseService.getDetailById(id));
    }

    @PostMapping("/detail")
    public Result<PurchaseDetail> createDetail(@RequestBody PurchaseDetail detail, HttpServletRequest request) {
        // All logged-in users can add purchase details
        return Result.success(purchaseService.createDetail(detail));
    }

    @PutMapping("/detail/{id}")
    public Result<PurchaseDetail> updateDetail(@PathVariable Long id, @RequestBody PurchaseDetail detail, HttpServletRequest request) {
        checkAdmin(request);
        return Result.success(purchaseService.updateDetail(id, detail));
    }

    @DeleteMapping("/detail/{id}")
    public Result<?> deleteDetail(@PathVariable Long id, HttpServletRequest request) {
        checkAdmin(request);
        purchaseService.deleteDetail(id);
        return Result.success();
    }

    // ============ Status Transition ============
    @PutMapping("/main/{id}/status")
    public Result<?> updateStatus(@PathVariable Long id, @RequestBody Map<String, Integer> body, HttpServletRequest request) {
        checkAdmin(request);
        Integer newStatus = body.get("status");
        if (newStatus == null || newStatus < 0 || newStatus > 4) {
            return Result.error("无效的状态值");
        }
        PurchaseMain pm = purchaseService.getMainById(id);
        pm.setStatus(newStatus);

        // When status becomes "completed" (3), auto-update product stock
        if (newStatus == 3) {
            List<PurchaseDetail> details = purchaseService.listDetailByMainId(id);
            for (PurchaseDetail d : details) {
                productRepository.findById(d.getProductId()).ifPresent(product -> {
                    int newStock = (product.getStockQuantity() == null ? 0 : product.getStockQuantity()) + (d.getQuantity() == null ? 0 : d.getQuantity());
                    product.setStockQuantity(newStock);
                    productRepository.save(product);
                });
            }
        }
        purchaseMainRepository.save(pm);
        return Result.success();
    }

    private void checkAdmin(HttpServletRequest request) {
        Integer level = (Integer) request.getAttribute("level");
        if (level == null || level != 1) {
            throw new RuntimeException("无管理员权限");
        }
    }
}
