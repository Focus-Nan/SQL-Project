package com.pms.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;

@Entity
@Table(name = "purchase_detail")
public class PurchaseDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "detail_no", length = 50)
    private String detailNo;

    @Column(name = "purchase_main_id", nullable = false)
    private Long purchaseMainId;

    @Column(name = "product_id", nullable = false)
    private Long productId;

    @Column(nullable = false)
    private Integer quantity;

    @Column(name = "unit_price", precision = 10, scale = 2)
    private Double unitPrice;

    @Column(name = "total_price", precision = 12, scale = 2)
    private Double totalPrice;

    @Column(length = 500)
    private String remark;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "purchase_main_id", insertable = false, updatable = false)
    @JsonIgnore
    private PurchaseMain purchaseMain;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "product_id", insertable = false, updatable = false)
    private Product product;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getDetailNo() { return detailNo; }
    public void setDetailNo(String detailNo) { this.detailNo = detailNo; }
    public Long getPurchaseMainId() { return purchaseMainId; }
    public void setPurchaseMainId(Long purchaseMainId) { this.purchaseMainId = purchaseMainId; }
    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }
    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }
    public Double getUnitPrice() { return unitPrice; }
    public void setUnitPrice(Double unitPrice) { this.unitPrice = unitPrice; }
    public Double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(Double totalPrice) { this.totalPrice = totalPrice; }
    public String getRemark() { return remark; }
    public void setRemark(String remark) { this.remark = remark; }
    public PurchaseMain getPurchaseMain() { return purchaseMain; }
    public void setPurchaseMain(PurchaseMain purchaseMain) { this.purchaseMain = purchaseMain; }
    public Product getProduct() { return product; }
}
