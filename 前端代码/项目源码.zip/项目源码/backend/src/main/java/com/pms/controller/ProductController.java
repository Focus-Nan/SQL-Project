package com.pms.controller;

import com.pms.common.Result;
import com.pms.entity.Product;
import com.pms.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping
    public Result<List<Product>> list(@RequestParam(required = false) String search) {
        return Result.success(productService.list(search));
    }

    @GetMapping("/{id}")
    public Result<Product> getById(@PathVariable Long id) {
        return Result.success(productService.getById(id));
    }

    @PostMapping
    public Result<Product> create(@RequestBody Product product, HttpServletRequest request) {
        checkAdmin(request);
        return Result.success(productService.create(product));
    }

    @PostMapping("/batch")
    public Result<List<Product>> batchImport(@RequestBody Map<String, String> body, HttpServletRequest request) {
        checkAdmin(request);
        String data = body.get("data");
        if (data == null || data.trim().isEmpty()) {
            return Result.error("导入数据不能为空");
        }
        return Result.success(productService.batchImport(data));
    }

    @PutMapping("/{id}")
    public Result<Product> update(@PathVariable Long id, @RequestBody Product product, HttpServletRequest request) {
        checkAdmin(request);
        return Result.success(productService.update(id, product));
    }

    @DeleteMapping("/{id}")
    public Result<?> delete(@PathVariable Long id, HttpServletRequest request) {
        checkAdmin(request);
        productService.delete(id);
        return Result.success();
    }

    private void checkAdmin(HttpServletRequest request) {
        Integer level = (Integer) request.getAttribute("level");
        if (level == null || level != 1) {
            throw new RuntimeException("无管理员权限");
        }
    }
}
