package com.pms.service;

import com.pms.entity.Employee;
import com.pms.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public List<Employee> list() {
        return employeeRepository.findAll();
    }

    public Employee getById(Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("员工不存在"));
    }

    public Employee create(Employee employee) {
        if (employeeRepository.existsByEmployeeNo(employee.getEmployeeNo())) {
            throw new RuntimeException("员工编号已存在");
        }
        // Encode password
        employee.setPassword(encoder.encode(employee.getPassword()));
        return employeeRepository.save(employee);
    }

    public List<Employee> batchImport(String data) {
        List<Employee> result = new ArrayList<>();
        String[] lines = data.split("\\n");
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            if (line.isEmpty()) continue;

            String[] parts = line.split("\\|");
            if (parts.length < 4) {
                if (line.contains("\t")) parts = line.split("\\t");
                else if (line.contains(",")) parts = line.split(",");
            }
            if (parts.length < 4) {
                throw new RuntimeException("第" + (i + 1) + "行格式错误: 至少需要员工编号、姓名、密码和级别");
            }

            Employee employee = new Employee();
            employee.setEmployeeNo(parts[0].trim());
            employee.setName(parts[1].trim());
            employee.setPassword(encoder.encode(parts[2].trim()));
            employee.setLevel(Integer.parseInt(parts[3].trim()));
            employee.setPhone(parts.length > 4 ? parts[4].trim() : null);
            employee.setSalary(parts.length > 5 && !parts[5].trim().isEmpty() ? Double.parseDouble(parts[5].trim()) : null);
            employee.setRemark(parts.length > 6 ? parts[6].trim() : null);

            if (employeeRepository.existsByEmployeeNo(employee.getEmployeeNo())) {
                throw new RuntimeException("第" + (i + 1) + "行: 员工编号 " + employee.getEmployeeNo() + " 已存在");
            }

            result.add(employeeRepository.save(employee));
        }
        return result;
    }

    public Employee update(Long id, Employee employee) {
        Employee existing = getById(id);
        existing.setEmployeeNo(employee.getEmployeeNo());
        existing.setName(employee.getName());
        // Only update password if provided
        if (employee.getPassword() != null && !employee.getPassword().isEmpty()) {
            existing.setPassword(encoder.encode(employee.getPassword()));
        }
        existing.setLevel(employee.getLevel());
        existing.setPhone(employee.getPhone());
        existing.setSalary(employee.getSalary());
        existing.setRemark(employee.getRemark());
        return employeeRepository.save(existing);
    }

    public void resetPassword(Long id, String newPassword) {
        Employee existing = getById(id);
        existing.setPassword(encoder.encode(newPassword));
        employeeRepository.save(existing);
    }

    public void delete(Long id) {
        if (!employeeRepository.existsById(id)) {
            throw new RuntimeException("员工不存在");
        }
        employeeRepository.deleteById(id);
    }
}
