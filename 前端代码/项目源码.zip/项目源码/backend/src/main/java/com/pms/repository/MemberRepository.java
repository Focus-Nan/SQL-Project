package com.pms.repository;

import com.pms.entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MemberRepository extends JpaRepository<Member, Long> {
    List<Member> findByNameContainingOrMemberNoContaining(String name, String memberNo);
    boolean existsByMemberNo(String memberNo);
}
