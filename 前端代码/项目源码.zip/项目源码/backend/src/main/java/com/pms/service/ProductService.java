package com.pms.service;

import com.pms.entity.Product;
import com.pms.entity.Supplier;
import com.pms.repository.ProductRepository;
import com.pms.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private SupplierRepository supplierRepository;

    public List<Product> list(String search) {
        if (StringUtils.hasText(search)) {
            return productRepository.findByNameContainingOrProductNoContaining(search, search);
        }
        return productRepository.findAll();
    }

    public Product getById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("商品不存在"));
    }

    public Product create(Product product) {
        if (productRepository.existsByProductNo(product.getProductNo())) {
            throw new RuntimeException("商品编号已存在");
        }
        return productRepository.save(product);
    }

    /**
     * Batch import products.
     * Supports '|', comma, or tab as delimiter.
     * Format: 编号|名称|单价|供应商(ID或名称)|简介|备注
     * Only columns 0-2 are required.
     * Column 3 accepts either a numeric supplier ID or a supplier name (auto-lookup).
     */
    public List<Product> batchImport(String data) {
        List<Product> result = new ArrayList<>();
        List<String> errors = new ArrayList<>();

        String[] lines = data.split("\\n");
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            if (line.isEmpty()) continue;

            try {
                // Auto-detect delimiter: tab, comma, or pipe
                String delimiter = "\\|";
                if (!line.contains("|")) {
                    if (line.contains("\t")) delimiter = "\\t";
                    else if (line.contains(",")) delimiter = ",";
                }

                String[] parts = line.split(delimiter);
                if (parts.length < 3) {
                    errors.add("第" + (i + 1) + "行: 至少需要商品编号、名称和单价");
                    continue;
                }

                Product product = new Product();
                product.setProductNo(parts[0].trim());
                product.setName(parts[1].trim());
                product.setPrice(Double.parseDouble(parts[2].trim()));

                // Column 4 (index 3): supplier ID or supplier name
                if (parts.length > 3 && !parts[3].trim().isEmpty()) {
                    String supplierField = parts[3].trim();
                    Long supplierId = resolveSupplier(supplierField);
                    if (supplierId == null) {
                        errors.add("第" + (i + 1) + "行: 供应商 '" + supplierField + "' 未找到");
                        continue;
                    }
                    product.setSupplierId(supplierId);
                }

                product.setDescription(parts.length > 4 ? parts[4].trim() : null);
                product.setRemark(parts.length > 5 ? parts[5].trim() : null);

                if (productRepository.existsByProductNo(product.getProductNo())) {
                    errors.add("第" + (i + 1) + "行: 编号 " + product.getProductNo() + " 已存在，已跳过");
                    continue;
                }

                result.add(productRepository.save(product));
            } catch (NumberFormatException e) {
                errors.add("第" + (i + 1) + "行: 单价格式错误");
            }
        }

        if (!errors.isEmpty() && result.isEmpty()) {
            throw new RuntimeException(String.join("; ", errors));
        }
        if (!errors.isEmpty()) {
            // Partial success - log errors but return what succeeded
            // The frontend will show both the success count and errors
            throw new RuntimeException("部分导入成功 (" + result.size() + "条)。跳过: " + String.join("; ", errors));
        }
        return result;
    }

    /**
     * Resolve supplier field: try as numeric ID first, then try as name (fuzzy).
     */
    private Long resolveSupplier(String field) {
        // Try as numeric ID
        try {
            Long id = Long.parseLong(field);
            if (supplierRepository.existsById(id)) {
                return id;
            }
        } catch (NumberFormatException ignored) {}

        // Try as supplier name (contains search)
        List<Supplier> matches = supplierRepository.findByNameContainingOrSupplierNoContaining(field, field);
        if (!matches.isEmpty()) {
            return matches.get(0).getId(); // first match
        }
        return null;
    }

    public Product update(Long id, Product product) {
        Product existing = getById(id);
        existing.setProductNo(product.getProductNo());
        existing.setName(product.getName());
        existing.setPrice(product.getPrice());
        existing.setSupplierId(product.getSupplierId());
        existing.setDescription(product.getDescription());
        existing.setRemark(product.getRemark());
        return productRepository.save(existing);
    }

    public void delete(Long id) {
        if (!productRepository.existsById(id)) {
            throw new RuntimeException("商品不存在");
        }
        productRepository.deleteById(id);
    }
}
