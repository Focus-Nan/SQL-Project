package com.pms.controller;

import com.pms.common.Result;
import com.pms.entity.Employee;
import com.pms.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public Result<List<Employee>> list() {
        return Result.success(employeeService.list());
    }

    @GetMapping("/{id}")
    public Result<Employee> getById(@PathVariable Long id) {
        return Result.success(employeeService.getById(id));
    }

    @PostMapping
    public Result<Employee> create(@RequestBody Employee employee, HttpServletRequest request) {
        checkAdmin(request);
        return Result.success(employeeService.create(employee));
    }

    @PostMapping("/batch")
    public Result<List<Employee>> batchImport(@RequestBody Map<String, String> body, HttpServletRequest request) {
        checkAdmin(request);
        String data = body.get("data");
        if (data == null || data.trim().isEmpty()) {
            return Result.error("导入数据不能为空");
        }
        return Result.success(employeeService.batchImport(data));
    }

    @PutMapping("/{id}")
    public Result<Employee> update(@PathVariable Long id, @RequestBody Employee employee, HttpServletRequest request) {
        checkAdmin(request);
        return Result.success(employeeService.update(id, employee));
    }

    @PutMapping("/{id}/reset-password")
    public Result<?> resetPassword(@PathVariable Long id, @RequestBody Map<String, String> body, HttpServletRequest request) {
        checkAdmin(request);
        String password = body.get("password");
        if (password == null || password.trim().isEmpty()) {
            return Result.error("密码不能为空");
        }
        employeeService.resetPassword(id, password.trim());
        return Result.success();
    }

    @DeleteMapping("/{id}")
    public Result<?> delete(@PathVariable Long id, HttpServletRequest request) {
        checkAdmin(request);
        employeeService.delete(id);
        return Result.success();
    }

    private void checkAdmin(HttpServletRequest request) {
        Integer level = (Integer) request.getAttribute("level");
        if (level == null || level != 1) {
            throw new RuntimeException("无管理员权限");
        }
    }
}
