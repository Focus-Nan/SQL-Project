package com.pms.service;

import com.pms.entity.Employee;
import com.pms.repository.EmployeeRepository;
import com.pms.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private JwtUtil jwtUtil;

    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public Map<String, Object> login(String employeeNo, String password) {
        Optional<Employee> opt = employeeRepository.findByEmployeeNo(employeeNo);
        if (!opt.isPresent()) {
            throw new RuntimeException("员工编号不存在");
        }

        Employee employee = opt.get();
        if (!encoder.matches(password, employee.getPassword())) {
            throw new RuntimeException("密码错误");
        }

        String token = jwtUtil.generateToken(employee.getId(), employee.getEmployeeNo(),
                employee.getName(), employee.getLevel());

        Map<String, Object> result = new HashMap<>();
        result.put("token", token);
        result.put("employeeId", employee.getId());
        result.put("employeeNo", employee.getEmployeeNo());
        result.put("name", employee.getName());
        result.put("level", employee.getLevel());
        result.put("phone", employee.getPhone());
        result.put("salary", employee.getSalary());
        result.put("avatar", employee.getAvatar());
        return result;
    }

    /**
     * Get current user info (used for /api/auth/me)
     */
    public Map<String, Object> getUserInfo(Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("员工不存在"));

        Map<String, Object> result = new HashMap<>();
        result.put("employeeId", employee.getId());
        result.put("employeeNo", employee.getEmployeeNo());
        result.put("name", employee.getName());
        result.put("level", employee.getLevel());
        result.put("phone", employee.getPhone());
        result.put("salary", employee.getSalary());
        result.put("remark", employee.getRemark());
        result.put("avatar", employee.getAvatar());
        return result;
    }

    /**
     * Self-registration for regular users
     */
    public Map<String, Object> register(String employeeNo, String name, String password, String phone) {
        if (employeeRepository.existsByEmployeeNo(employeeNo)) {
            throw new RuntimeException("该账号已存在，请更换");
        }
        Employee employee = new Employee();
        employee.setEmployeeNo(employeeNo);
        employee.setName(name);
        employee.setPassword(encoder.encode(password));
        employee.setLevel(2); // regular user
        employee.setPhone(phone);
        employee.setSalary(0.0);
        employee.setRemark("自主注册用户");
        employeeRepository.save(employee);

        // Auto login after registration
        String token = jwtUtil.generateToken(employee.getId(), employee.getEmployeeNo(),
                employee.getName(), employee.getLevel());

        Map<String, Object> result = new HashMap<>();
        result.put("token", token);
        result.put("employeeId", employee.getId());
        result.put("employeeNo", employee.getEmployeeNo());
        result.put("name", employee.getName());
        result.put("level", employee.getLevel());
        result.put("phone", employee.getPhone());
        return result;
    }

    public String getAvatarByEmployeeNo(String employeeNo) {
        return employeeRepository.findByEmployeeNo(employeeNo)
                .map(Employee::getAvatar)
                .orElse(null);
    }

    public void updateAvatar(Long employeeId, String base64) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("员工不存在"));
        employee.setAvatar(base64);
        employeeRepository.save(employee);
    }

    /**
     * Encode raw password - utility method for creating initial data
     */
    public String encodePassword(String raw) {
        return encoder.encode(raw);
    }
}
