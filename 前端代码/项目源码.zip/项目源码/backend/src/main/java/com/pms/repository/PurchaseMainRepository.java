package com.pms.repository;

import com.pms.entity.PurchaseMain;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PurchaseMainRepository extends JpaRepository<PurchaseMain, Long> {
    List<PurchaseMain> findByEmployeeId(Long employeeId);
    boolean existsByPurchaseNo(String purchaseNo);
}
