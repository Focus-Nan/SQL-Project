package com.pms.service;

import com.pms.entity.Member;
import com.pms.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

@Service
public class MemberService {

    @Autowired
    private MemberRepository memberRepository;

    public List<Member> list(String search) {
        if (StringUtils.hasText(search)) {
            return memberRepository.findByNameContainingOrMemberNoContaining(search, search);
        }
        return memberRepository.findAll();
    }

    public Member getById(Long id) {
        return memberRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("会员不存在"));
    }

    public Member create(Member member) {
        if (memberRepository.existsByMemberNo(member.getMemberNo())) {
            throw new RuntimeException("会员编号已存在");
        }
        return memberRepository.save(member);
    }

    public List<Member> batchImport(String data) {
        List<Member> result = new ArrayList<>();
        String[] lines = data.split("\\n");
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            if (line.isEmpty()) continue;

            String[] parts = line.split("\\|");
            if (parts.length < 2) {
                throw new RuntimeException("第" + (i + 1) + "行格式错误: 至少需要会员编号和姓名");
            }

            Member member = new Member();
            member.setMemberNo(parts[0].trim());
            member.setName(parts[1].trim());
            member.setPhone(parts.length > 2 ? parts[2].trim() : null);
            member.setAddress(parts.length > 3 ? parts[3].trim() : null);
            member.setEmail(parts.length > 4 ? parts[4].trim() : null);
            member.setDiscount(parts.length > 5 && !parts[5].trim().isEmpty() ? Double.parseDouble(parts[5].trim()) : 1.0);
            member.setRemark(parts.length > 6 ? parts[6].trim() : null);

            if (memberRepository.existsByMemberNo(member.getMemberNo())) {
                throw new RuntimeException("第" + (i + 1) + "行: 会员编号 " + member.getMemberNo() + " 已存在");
            }

            result.add(memberRepository.save(member));
        }
        return result;
    }

    public Member update(Long id, Member member) {
        Member existing = getById(id);
        existing.setMemberNo(member.getMemberNo());
        existing.setName(member.getName());
        existing.setPhone(member.getPhone());
        existing.setAddress(member.getAddress());
        existing.setEmail(member.getEmail());
        existing.setDiscount(member.getDiscount());
        existing.setRemark(member.getRemark());
        return memberRepository.save(existing);
    }

    public void delete(Long id) {
        if (!memberRepository.existsById(id)) {
            throw new RuntimeException("会员不存在");
        }
        memberRepository.deleteById(id);
    }
}
