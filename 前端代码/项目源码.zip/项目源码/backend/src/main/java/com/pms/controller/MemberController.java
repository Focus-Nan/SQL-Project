package com.pms.controller;

import com.pms.common.Result;
import com.pms.entity.Member;
import com.pms.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/members")
public class MemberController {

    @Autowired
    private MemberService memberService;

    @GetMapping
    public Result<List<Member>> list(@RequestParam(required = false) String search) {
        return Result.success(memberService.list(search));
    }

    @GetMapping("/{id}")
    public Result<Member> getById(@PathVariable Long id) {
        return Result.success(memberService.getById(id));
    }

    @PostMapping
    public Result<Member> create(@RequestBody Member member, HttpServletRequest request) {
        checkAdmin(request);
        return Result.success(memberService.create(member));
    }

    @PostMapping("/batch")
    public Result<List<Member>> batchImport(@RequestBody Map<String, String> body, HttpServletRequest request) {
        checkAdmin(request);
        String data = body.get("data");
        if (data == null || data.trim().isEmpty()) {
            return Result.error("导入数据不能为空");
        }
        return Result.success(memberService.batchImport(data));
    }

    @PutMapping("/{id}")
    public Result<Member> update(@PathVariable Long id, @RequestBody Member member, HttpServletRequest request) {
        checkAdmin(request);
        return Result.success(memberService.update(id, member));
    }

    @DeleteMapping("/{id}")
    public Result<?> delete(@PathVariable Long id, HttpServletRequest request) {
        checkAdmin(request);
        memberService.delete(id);
        return Result.success();
    }

    private void checkAdmin(HttpServletRequest request) {
        Integer level = (Integer) request.getAttribute("level");
        if (level == null || level != 1) {
            throw new RuntimeException("无管理员权限");
        }
    }
}
