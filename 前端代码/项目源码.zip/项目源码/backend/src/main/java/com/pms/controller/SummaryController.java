package com.pms.controller;

import com.pms.common.Result;
import com.pms.entity.*;
import com.pms.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/summary")
public class SummaryController {

    @Autowired private EmployeeRepository employeeRepository;
    @Autowired private PurchaseMainRepository purchaseMainRepository;
    @Autowired private PurchaseDetailRepository purchaseDetailRepository;
    @Autowired private ProductRepository productRepository;
    @Autowired private SupplierRepository supplierRepository;

    /**
     * Employee KPI: purchase count + total amount per employee, with level assignment
     */
    @GetMapping("/employee-kpi")
    public Result<List<Map<String, Object>>> employeeKpi() {
        List<Employee> employees = employeeRepository.findAll();
        List<PurchaseMain> allPurchases = purchaseMainRepository.findAll();

        // Aggregate purchases by employee
        Map<Long, List<PurchaseMain>> byEmployee = allPurchases.stream()
                .collect(Collectors.groupingBy(PurchaseMain::getEmployeeId));

        List<Map<String, Object>> result = new ArrayList<>();
        for (Employee emp : employees) {
            List<PurchaseMain> purchases = byEmployee.getOrDefault(emp.getId(), Collections.emptyList());
            int count = purchases.size();
            double total = purchases.stream().mapToDouble(p -> p.getTotalPrice() != null ? p.getTotalPrice() : 0).sum();

            // Determine level based on total purchase amount
            String level;
            double suggestedSalary;
            if (total >= 100000) {
                level = "S级";
                suggestedSalary = 15000;
            } else if (total >= 50000) {
                level = "A级";
                suggestedSalary = 12000;
            } else if (total >= 20000) {
                level = "B级";
                suggestedSalary = 9000;
            } else if (total >= 5000) {
                level = "C级";
                suggestedSalary = 7000;
            } else {
                level = "D级";
                suggestedSalary = 5000;
            }

            Map<String, Object> map = new HashMap<>();
            map.put("employeeId", emp.getId());
            map.put("employeeNo", emp.getEmployeeNo());
            map.put("name", emp.getName());
            map.put("currentSalary", emp.getSalary());
            map.put("purchaseCount", count);
            map.put("purchaseTotal", Math.round(total * 100.0) / 100.0);
            map.put("kpiLevel", level);
            map.put("suggestedSalary", suggestedSalary);
            map.put("level", emp.getLevel());
            result.add(map);
        }

        // Sort by purchase total descending
        result.sort((a, b) -> Double.compare(
                (Double) b.get("purchaseTotal"), (Double) a.get("purchaseTotal")));
        return Result.success(result);
    }

    /**
     * Purchase expenditure summary grouped by employee
     */
    @GetMapping("/purchase-expenditure")
    public Result<Map<String, Object>> purchaseExpenditure() {
        List<PurchaseMain> all = purchaseMainRepository.findAll();

        // Group by employee
        Map<String, Double> byEmployee = new LinkedHashMap<>();
        Map<Long, String> empNames = new HashMap<>();
        employeeRepository.findAll().forEach(e -> empNames.put(e.getId(), e.getName()));

        for (PurchaseMain pm : all) {
            String name = empNames.getOrDefault(pm.getEmployeeId(), "未知");
            byEmployee.merge(name, pm.getTotalPrice() != null ? pm.getTotalPrice() : 0.0, Double::sum);
        }

        double grandTotal = all.stream().mapToDouble(p -> p.getTotalPrice() != null ? p.getTotalPrice() : 0).sum();

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("byEmployee", byEmployee);
        result.put("grandTotal", Math.round(grandTotal * 100.0) / 100.0);
        result.put("purchaseCount", all.size());
        return Result.success(result);
    }

    /**
     * Product distribution: count of products grouped by supplier
     */
    @GetMapping("/product-distribution")
    public Result<List<Map<String, Object>>> productDistribution() {
        List<Product> products = productRepository.findAll();
        List<Supplier> suppliers = supplierRepository.findAll();
        Map<Long, String> supNames = new HashMap<>();
        suppliers.forEach(s -> supNames.put(s.getId(), s.getName()));

        // Group by supplier
        Map<String, Long> distribution = new LinkedHashMap<>();
        for (Product p : products) {
            String supName = p.getSupplierId() != null ? supNames.getOrDefault(p.getSupplierId(), "未分类") : "未分类";
            distribution.merge(supName, 1L, Long::sum);
        }

        List<Map<String, Object>> result = new ArrayList<>();
        distribution.forEach((name, count) -> {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("name", name);
            item.put("value", count);
            result.add(item);
        });

        return Result.success(result);
    }
}
