package com.pms.controller;

import com.pms.common.Result;
import com.pms.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public Result<?> login(@RequestBody Map<String, String> loginData) {
        String employeeNo = loginData.get("employeeNo");
        String password = loginData.get("password");
        if (employeeNo == null || password == null) {
            return Result.error("员工编号和密码不能为空");
        }
        Map<String, Object> data = authService.login(employeeNo, password);
        return Result.success(data);
    }

    @PostMapping("/register")
    public Result<?> register(@RequestBody Map<String, String> data) {
        String employeeNo = data.get("employeeNo");
        String name = data.get("name");
        String password = data.get("password");
        String phone = data.get("phone");
        if (employeeNo == null || employeeNo.trim().isEmpty()) {
            return Result.error("账号不能为空");
        }
        if (name == null || name.trim().isEmpty()) {
            return Result.error("姓名不能为空");
        }
        if (password == null || password.length() < 4) {
            return Result.error("密码至少4位");
        }
        Map<String, Object> result = authService.register(employeeNo.trim(), name.trim(), password, phone);
        return Result.success(result);
    }

    @GetMapping("/me")
    public Result<?> me(HttpServletRequest request) {
        Long employeeId = (Long) request.getAttribute("employeeId");
        Map<String, Object> data = authService.getUserInfo(employeeId);
        return Result.success(data);
    }

    @PostMapping("/avatar")
    public Result<?> uploadAvatar(@RequestBody Map<String, String> body, HttpServletRequest request) {
        Long employeeId = (Long) request.getAttribute("employeeId");
        String base64 = body.get("avatar");
        if (base64 == null || base64.isEmpty()) {
            return Result.error("头像数据为空");
        }
        authService.updateAvatar(employeeId, base64);
        return Result.success();
    }

    @GetMapping("/avatar/{employeeNo}")
    public Result<String> getAvatar(@PathVariable String employeeNo) {
        String avatar = authService.getAvatarByEmployeeNo(employeeNo);
        return Result.success(avatar);
    }
}
