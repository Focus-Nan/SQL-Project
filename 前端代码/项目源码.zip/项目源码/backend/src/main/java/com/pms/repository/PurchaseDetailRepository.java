package com.pms.repository;

import com.pms.entity.PurchaseDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PurchaseDetailRepository extends JpaRepository<PurchaseDetail, Long> {
    List<PurchaseDetail> findByPurchaseMainId(Long purchaseMainId);
    void deleteByPurchaseMainId(Long purchaseMainId);
}
