package com.pms.interceptor;

import com.pms.util.JwtUtil;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
public class AuthInterceptor implements HandlerInterceptor {

    @Autowired
    private JwtUtil jwtUtil;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // Handle preflight CORS requests
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            return true;
        }

        String token = request.getHeader("Authorization");
        if (token == null || !token.startsWith("Bearer ")) {
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write("{\"code\":401,\"msg\":\"未登录或token无效\",\"data\":null}");
            return false;
        }

        token = token.substring(7);
        if (!jwtUtil.validateToken(token)) {
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write("{\"code\":401,\"msg\":\"token已过期或无效\",\"data\":null}");
            return false;
        }

        // Set user info in request attributes for controllers to use
        Claims claims = jwtUtil.parseToken(token);
        request.setAttribute("employeeId", claims.get("employeeId", Long.class));
        request.setAttribute("employeeNo", claims.get("employeeNo", String.class));
        request.setAttribute("name", claims.get("name", String.class));
        request.setAttribute("level", claims.get("level", Integer.class));

        return true;
    }
}
