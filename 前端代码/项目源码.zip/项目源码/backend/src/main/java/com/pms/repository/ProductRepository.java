package com.pms.repository;

import com.pms.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByNameContainingOrProductNoContaining(String name, String productNo);
    boolean existsByProductNo(String productNo);
}
