package com.pms.service;

import com.pms.entity.PurchaseDetail;
import com.pms.entity.PurchaseMain;
import com.pms.repository.PurchaseDetailRepository;
import com.pms.repository.PurchaseMainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PurchaseService {

    @Autowired
    private PurchaseMainRepository purchaseMainRepository;

    @Autowired
    private PurchaseDetailRepository purchaseDetailRepository;

    // ============ Purchase Main ============

    public List<PurchaseMain> listMain(Long employeeId) {
        if (employeeId != null) {
            return purchaseMainRepository.findByEmployeeId(employeeId);
        }
        return purchaseMainRepository.findAll();
    }

    public PurchaseMain getMainById(Long id) {
        return purchaseMainRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("采购主表记录不存在"));
    }

    public PurchaseMain createMain(PurchaseMain main) {
        if (purchaseMainRepository.existsByPurchaseNo(main.getPurchaseNo())) {
            throw new RuntimeException("采购清单号已存在");
        }
        return purchaseMainRepository.save(main);
    }

    public PurchaseMain updateMain(Long id, PurchaseMain main) {
        PurchaseMain existing = getMainById(id);
        existing.setPurchaseNo(main.getPurchaseNo());
        existing.setEmployeeId(main.getEmployeeId());
        existing.setTotalQuantity(main.getTotalQuantity());
        existing.setTotalPrice(main.getTotalPrice());
        existing.setPurchaseTime(main.getPurchaseTime());
        existing.setRemark(main.getRemark());
        return purchaseMainRepository.save(existing);
    }

    @Transactional
    public void deleteMain(Long id) {
        if (!purchaseMainRepository.existsById(id)) {
            throw new RuntimeException("采购主表记录不存在");
        }
        // Delete details first, then main
        purchaseDetailRepository.deleteByPurchaseMainId(id);
        purchaseMainRepository.deleteById(id);
    }

    // ============ Purchase Detail ============

    public List<PurchaseDetail> listDetailByMainId(Long mainId) {
        return purchaseDetailRepository.findByPurchaseMainId(mainId);
    }

    public List<PurchaseDetail> listAllDetails() {
        return purchaseDetailRepository.findAll();
    }

    public PurchaseDetail getDetailById(Long id) {
        return purchaseDetailRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("采购明细不存在"));
    }

    public PurchaseDetail createDetail(PurchaseDetail detail) {
        // Verify the main record exists
        if (!purchaseMainRepository.existsById(detail.getPurchaseMainId())) {
            throw new RuntimeException("采购清单不存在");
        }
        return purchaseDetailRepository.save(detail);
    }

    public PurchaseDetail updateDetail(Long id, PurchaseDetail detail) {
        PurchaseDetail existing = getDetailById(id);
        existing.setDetailNo(detail.getDetailNo());
        existing.setProductId(detail.getProductId());
        existing.setQuantity(detail.getQuantity());
        existing.setUnitPrice(detail.getUnitPrice());
        existing.setTotalPrice(detail.getTotalPrice());
        existing.setRemark(detail.getRemark());
        return purchaseDetailRepository.save(existing);
    }

    public void deleteDetail(Long id) {
        if (!purchaseDetailRepository.existsById(id)) {
            throw new RuntimeException("采购明细不存在");
        }
        purchaseDetailRepository.deleteById(id);
    }
}
