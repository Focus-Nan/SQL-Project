package com.pms.controller;

import com.pms.common.Result;
import com.pms.entity.Supplier;
import com.pms.service.SupplierService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/suppliers")
public class SupplierController {

    @Autowired
    private SupplierService supplierService;

    @GetMapping
    public Result<List<Supplier>> list(@RequestParam(required = false) String search) {
        return Result.success(supplierService.list(search));
    }

    @GetMapping("/{id}")
    public Result<Supplier> getById(@PathVariable Long id) {
        return Result.success(supplierService.getById(id));
    }

    @PostMapping
    public Result<Supplier> create(@RequestBody Supplier supplier, HttpServletRequest request) {
        checkAdmin(request);
        return Result.success(supplierService.create(supplier));
    }

    @PostMapping("/batch")
    public Result<List<Supplier>> batchImport(@RequestBody Map<String, String> body, HttpServletRequest request) {
        checkAdmin(request);
        String data = body.get("data");
        if (data == null || data.trim().isEmpty()) {
            return Result.error("导入数据不能为空");
        }
        return Result.success(supplierService.batchImport(data));
    }

    @PutMapping("/{id}")
    public Result<Supplier> update(@PathVariable Long id, @RequestBody Supplier supplier, HttpServletRequest request) {
        checkAdmin(request);
        return Result.success(supplierService.update(id, supplier));
    }

    @DeleteMapping("/{id}")
    public Result<?> delete(@PathVariable Long id, HttpServletRequest request) {
        checkAdmin(request);
        supplierService.delete(id);
        return Result.success();
    }

    private void checkAdmin(HttpServletRequest request) {
        Integer level = (Integer) request.getAttribute("level");
        if (level == null || level != 1) {
            throw new RuntimeException("无管理员权限");
        }
    }
}
