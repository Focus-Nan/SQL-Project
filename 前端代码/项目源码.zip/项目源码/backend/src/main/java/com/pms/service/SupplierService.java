package com.pms.service;

import com.pms.entity.Supplier;
import com.pms.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

@Service
public class SupplierService {

    @Autowired
    private SupplierRepository supplierRepository;

    public List<Supplier> list(String search) {
        if (StringUtils.hasText(search)) {
            return supplierRepository.findByNameContainingOrSupplierNoContaining(search, search);
        }
        return supplierRepository.findAll();
    }

    public Supplier getById(Long id) {
        return supplierRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("供应商不存在"));
    }

    public Supplier create(Supplier supplier) {
        if (supplierRepository.existsBySupplierNo(supplier.getSupplierNo())) {
            throw new RuntimeException("供应商编号已存在");
        }
        return supplierRepository.save(supplier);
    }

    /**
     * Batch import - each line format:
     * supplierNo|name|shortName|address|phone|email|contactPerson|contactPhone|remark
     */
    public List<Supplier> batchImport(String data) {
        List<Supplier> result = new ArrayList<>();
        String[] lines = data.split("\\n");
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            if (line.isEmpty()) continue;

            String[] parts = line.split("\\|");
            // Auto-detect delimiter fallback
            if (parts.length < 2) {
                if (line.contains("\t")) parts = line.split("\\t");
                else if (line.contains(",")) parts = line.split(",");
            }
            if (parts.length < 2) {
                throw new RuntimeException("第" + (i + 1) + "行格式错误: 至少需要供应商编号和名称");
            }

            Supplier supplier = new Supplier();
            supplier.setSupplierNo(parts[0].trim());
            supplier.setName(parts[1].trim());
            supplier.setShortName(parts.length > 2 ? parts[2].trim() : null);
            supplier.setAddress(parts.length > 3 ? parts[3].trim() : null);
            supplier.setPhone(parts.length > 4 ? parts[4].trim() : null);
            supplier.setEmail(parts.length > 5 ? parts[5].trim() : null);
            supplier.setContactPerson(parts.length > 6 ? parts[6].trim() : null);
            supplier.setContactPhone(parts.length > 7 ? parts[7].trim() : null);
            supplier.setRemark(parts.length > 8 ? parts[8].trim() : null);

            if (supplierRepository.existsBySupplierNo(supplier.getSupplierNo())) {
                throw new RuntimeException("第" + (i + 1) + "行: 供应商编号 " + supplier.getSupplierNo() + " 已存在");
            }

            result.add(supplierRepository.save(supplier));
        }
        return result;
    }

    public Supplier update(Long id, Supplier supplier) {
        Supplier existing = getById(id);
        existing.setSupplierNo(supplier.getSupplierNo());
        existing.setName(supplier.getName());
        existing.setShortName(supplier.getShortName());
        existing.setAddress(supplier.getAddress());
        existing.setPhone(supplier.getPhone());
        existing.setEmail(supplier.getEmail());
        existing.setContactPerson(supplier.getContactPerson());
        existing.setContactPhone(supplier.getContactPhone());
        existing.setRemark(supplier.getRemark());
        return supplierRepository.save(existing);
    }

    public void delete(Long id) {
        if (!supplierRepository.existsById(id)) {
            throw new RuntimeException("供应商不存在");
        }
        supplierRepository.deleteById(id);
    }
}
