<template>
  <router-view v-slot="{ Component, route }">
    <transition :name="route.meta.transition || 'page-fade'" mode="out-in">
      <component :is="Component" :key="route.path" />
    </transition>
  </router-view>
</template>

<script setup>
</script>

<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body, #app { height: 100%; font-family: 'Inter', 'Helvetica Neue', 'PingFang SC', 'Microsoft YaHei', sans-serif; }

/* Smooth theme transition */
html {
  transition: background-color 0.3s ease, color 0.3s ease;
}

/* ===== CSS Custom Properties — Light Mode (default) ===== */
:root {
  /* Backgrounds */
  --pms-bg-page: #f1f5f9;
  --pms-bg-card: #fff;
  --pms-bg-hover: #f1f5f9;
  --pms-bg-input: #fff;

  /* Text hierarchy */
  --pms-text-primary: #1e293b;
  --pms-text-secondary: #334155;
  --pms-text-tertiary: #475569;
  --pms-text-muted: #64748b;
  --pms-text-placeholder: #94a3b8;
  --pms-text-disabled: #cbd5e1;

  /* Borders */
  --pms-border-color: #e2e8f0;
  --pms-border-light: #f0f0f0;
  --pms-border-subtle: #f1f5f9;

  /* Accents */
  --pms-accent-primary: #6366f1;
  --pms-accent-secondary: #8b5cf6;
  --pms-accent-green: #10b981;
  --pms-accent-red: #ef4444;
  --pms-accent-amber: #f59e0b;
  --pms-accent-cyan: #06b6d4;
  --pms-accent-pink: #ec4899;
  --pms-accent-primary-light: rgba(99,102,241,0.08);

  /* Sidebar (admin) */
  --pms-sidebar-bg: #0f172a;
  --pms-sidebar-text: rgba(255,255,255,0.55);
  --pms-sidebar-text-hover: rgba(255,255,255,0.85);
  --pms-sidebar-active-bg: rgba(99,102,241,0.25);
  --pms-sidebar-active-text: #fff;
  --pms-sidebar-border: rgba(255,255,255,0.06);
  --pms-sidebar-collapse: rgba(255,255,255,0.3);
  --pms-sidebar-collapse-hover: rgba(255,255,255,0.6);

  /* User sidebar */
  --pms-user-sidebar-bg: #fff;
  --pms-user-sidebar-text: #64748b;
  --pms-user-sidebar-hover-bg: #f1f5f9;
  --pms-user-sidebar-hover-text: #334155;
  --pms-user-sidebar-active-bg: #ecfdf5;
  --pms-user-sidebar-active-text: #059669;
  --pms-user-sidebar-border: #f1f5f9;

  /* Shadows */
  --pms-shadow-card: 0 2px 10px rgba(0,0,0,0.04);
  --pms-shadow-card-hover: 0 8px 25px rgba(99,102,241,0.08);

  /* Login */
  --pms-login-bg: #0f0f1a;

  /* Table */
  --pms-table-header-bg: #f8fafc;
  --pms-table-row-hover: #eef2ff;
  --pms-card-divider: #f1f5f9;
}

/* ===== CSS Custom Properties — Dark Mode ===== */
html.dark {
  /* Backgrounds */
  --pms-bg-page: #0f1219;
  --pms-bg-card: #1a1d27;
  --pms-bg-hover: #242732;
  --pms-bg-input: #1a1d27;

  /* Text hierarchy */
  --pms-text-primary: #e5eaf3;
  --pms-text-secondary: #cfd3dc;
  --pms-text-tertiary: #a3a6ad;
  --pms-text-muted: #8d9095;
  --pms-text-placeholder: #6c6e72;
  --pms-text-disabled: #58585b;

  /* Borders */
  --pms-border-color: #2d3038;
  --pms-border-light: #24272e;
  --pms-border-subtle: #1e2128;

  /* Accents (slightly brighter for dark bg) */
  --pms-accent-primary: #818cf8;
  --pms-accent-secondary: #a78bfa;
  --pms-accent-green: #34d399;
  --pms-accent-red: #f87171;
  --pms-accent-amber: #fbbf24;
  --pms-accent-cyan: #22d3ee;
  --pms-accent-pink: #f472b6;
  --pms-accent-primary-light: rgba(129,140,248,0.12);

  /* Sidebar (admin) — slightly darker */
  --pms-sidebar-bg: #060b14;
  --pms-sidebar-text: rgba(255,255,255,0.45);
  --pms-sidebar-text-hover: rgba(255,255,255,0.75);
  --pms-sidebar-active-bg: rgba(129,140,248,0.2);
  --pms-sidebar-active-text: #e0e7ff;
  --pms-sidebar-border: rgba(255,255,255,0.04);
  --pms-sidebar-collapse: rgba(255,255,255,0.25);
  --pms-sidebar-collapse-hover: rgba(255,255,255,0.55);

  /* User sidebar */
  --pms-user-sidebar-bg: #1a1d27;
  --pms-user-sidebar-text: #8d9095;
  --pms-user-sidebar-hover-bg: #242732;
  --pms-user-sidebar-hover-text: #cfd3dc;
  --pms-user-sidebar-active-bg: rgba(52,211,153,0.12);
  --pms-user-sidebar-active-text: #34d399;
  --pms-user-sidebar-border: #1e2128;

  /* Shadows */
  --pms-shadow-card: 0 2px 10px rgba(0,0,0,0.2);
  --pms-shadow-card-hover: 0 8px 25px rgba(0,0,0,0.3);

  /* Login */
  --pms-login-bg: #0a0a14;

  /* Table */
  --pms-table-header-bg: #1e2128;
  --pms-table-row-hover: rgba(129,140,248,0.06);
  --pms-card-divider: #1e2128;
}

/* Page transitions */
.page-fade-enter-active { transition: all 0.25s ease-out; }
.page-fade-leave-active { transition: all 0.15s ease-in; }
.page-fade-enter-from { opacity: 0; transform: translateY(8px); }
.page-fade-leave-to { opacity: 0; transform: translateY(-4px); }

/* Global subtle animation mixins */
@keyframes fadeUp {
  from { opacity: 0; transform: translateY(12px); }
  to { opacity: 1; transform: translateY(0); }
}
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}
@keyframes scaleIn {
  from { opacity: 0; transform: scale(0.95); }
  to { opacity: 1; transform: scale(1); }
}
@keyframes countUp {
  from { opacity: 0; }
  to { opacity: 1; }
}
@keyframes shimmer {
  0% { background-position: -200% 0; }
  100% { background-position: 200% 0; }
}
@keyframes pulse-glow {
  0%, 100% { box-shadow: 0 0 0 0 rgba(99,102,241,0); }
  50% { box-shadow: 0 0 0 6px var(--pms-accent-primary-light); }
}

/* Global card hover glow */
.card-hover-glow {
  transition: all 0.3s ease;
}
.card-hover-glow:hover {
  transform: translateY(-2px);
  box-shadow: var(--pms-shadow-card-hover);
}

/* Shimmer loading */
.shimmer-bg {
  background: linear-gradient(90deg, var(--pms-bg-hover) 25%, var(--pms-border-color) 50%, var(--pms-bg-hover) 75%);
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
}

/* Staggered entrance for lists */
.stagger-item { animation: fadeUp 0.4s ease both; }

/* ===== Global micro-interactions ===== */
/* Table row slide-in */
.el-table__body tr {
  animation: fadeUp 0.35s ease both;
}
.el-table__body tr:nth-child(1) { animation-delay: 0.02s; }
.el-table__body tr:nth-child(2) { animation-delay: 0.04s; }
.el-table__body tr:nth-child(3) { animation-delay: 0.06s; }
.el-table__body tr:nth-child(4) { animation-delay: 0.08s; }
.el-table__body tr:nth-child(5) { animation-delay: 0.10s; }
.el-table__body tr:nth-child(6) { animation-delay: 0.12s; }
.el-table__body tr:nth-child(7) { animation-delay: 0.14s; }
.el-table__body tr:nth-child(8) { animation-delay: 0.16s; }
.el-table__body tr:nth-child(n+9) { animation-delay: 0.18s; }

/* Card list stagger */
.card-list-enter { animation: scaleIn 0.3s ease both; }

/* Button press effect */
.el-button:active { transform: scale(0.97) !important; }
.el-button { transition: all 0.2s ease !important; }

/* Input glow on focus */
.el-input__wrapper { transition: all 0.25s ease !important; }

/* Dialog entrance */
.el-dialog { animation: scaleIn 0.25s ease; }
@keyframes scaleIn {
  from { opacity: 0; transform: scale(0.95) translateY(-10px); }
  to { opacity: 1; transform: scale(1) translateY(0); }
}

/* Tag hover */
.el-tag { transition: transform 0.15s ease; }
.el-tag:hover { transform: scale(1.05); }

/* Admin page header entrance */
.page-top { animation: fadeUp 0.4s ease both; }
.section-card { animation: fadeUp 0.4s ease both; animation-delay: 0.1s; }
.table-wrap { animation: fadeUp 0.4s ease both; animation-delay: 0.08s; }

/* Nav item ripple */
.sb-item, .us-item {
  position: relative; overflow: hidden;
}
.sb-item::after, .us-item::after {
  content: ''; position: absolute; inset: 0;
  background: radial-gradient(circle at center, rgba(255,255,255,0.1) 0%, transparent 70%);
  opacity: 0; transition: opacity 0.3s;
}
.sb-item:hover::after, .us-item:hover::after { opacity: 1; }
</style>
