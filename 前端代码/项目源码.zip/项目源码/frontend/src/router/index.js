import { createRouter, createWebHistory } from 'vue-router'
import { useUserStore } from '../store/user'

const routes = [
  {
    path: '/',
    redirect: '/login'
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/Login.vue'),
    meta: { noAuth: true }
  },
  // ============ Admin Routes ============
  {
    path: '/admin',
    component: () => import('../views/admin/AdminLayout.vue'),
    meta: { requireAdmin: true },
    children: [
      {
        path: '',
        redirect: '/admin/dashboard'
      },
      {
        path: 'dashboard',
        name: 'AdminDashboard',
        component: () => import('../views/admin/Dashboard.vue')
      },
      {
        path: 'suppliers',
        name: 'SupplierManage',
        component: () => import('../views/admin/SupplierManage.vue')
      },
      {
        path: 'products',
        name: 'ProductManage',
        component: () => import('../views/admin/ProductManage.vue')
      },
      {
        path: 'employees',
        name: 'EmployeeManage',
        component: () => import('../views/admin/EmployeeManage.vue')
      },
      {
        path: 'purchases',
        name: 'PurchaseManage',
        component: () => import('../views/admin/PurchaseManage.vue')
      }
    ]
  },
  // ============ User Routes ============
  {
    path: '/user',
    component: () => import('../views/user/UserLayout.vue'),
    meta: { requireAuth: true },
    children: [
      {
        path: '',
        redirect: '/user/myinfo'
      },
      {
        path: 'myinfo',
        name: 'MyInfo',
        component: () => import('../views/user/MyInfo.vue')
      },
      {
        path: 'products',
        name: 'ProductList',
        component: () => import('../views/user/ProductList.vue')
      },
      {
        path: 'purchases',
        name: 'PurchaseList',
        component: () => import('../views/user/PurchaseList.vue')
      }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// Navigation Guard
router.beforeEach((to, from, next) => {
  const userStore = useUserStore()
  const token = userStore.token
  const isAdmin = userStore.isAdmin()

  // Allow login page
  if (to.meta.noAuth) {
    if (token) {
      // Already logged in, redirect to appropriate dashboard
      next(isAdmin ? '/admin/dashboard' : '/user/myinfo')
    } else {
      next()
    }
    return
  }

  // Check authentication
  if (!token) {
    next('/login')
    return
  }

  // Check admin routes
  if (to.meta.requireAdmin && !isAdmin) {
    next('/user/myinfo')
    return
  }

  // If admin tries to access user routes, redirect to admin
  if (to.path.startsWith('/user') && isAdmin) {
    next('/admin/dashboard')
    return
  }

  next()
})

export default router
