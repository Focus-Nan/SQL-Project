<template>
  <el-button text circle class="theme-toggle" @click="cycle" :title="label">
    <el-icon :size="17">
      <Sunny v-if="store.mode === 'light'" />
      <Moon v-if="store.mode === 'dark'" />
      <Histogram v-if="store.mode === 'auto'" />
    </el-icon>
  </el-button>
</template>

<script setup>
import { computed } from 'vue'
import { useThemeStore } from '../store/theme'

const store = useThemeStore()
const modes = ['light', 'dark', 'auto']
const labels = { light: '浅色模式', dark: '深色模式', auto: '跟随系统' }
const label = computed(() => labels[store.mode])

function cycle() {
  const idx = modes.indexOf(store.mode)
  store.setMode(modes[(idx + 1) % 3])
}
</script>

<style scoped>
.theme-toggle {
  color: var(--pms-text-muted, #94a3b8);
  transition: color 0.2s, transform 0.3s;
}
.theme-toggle:hover {
  color: var(--pms-accent-primary, #6366f1);
  transform: rotate(15deg);
}
</style>
