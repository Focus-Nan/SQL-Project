import * as XLSX from 'xlsx'
import { saveAs } from 'file-saver'

/**
 * Export JSON array data to Excel file
 * @param {Array} data - Array of objects
 * @param {string} fileName - Output filename without extension
 * @param {Array} columns - [{prop:'key',label:'列名'}] or null to export all
 */
export function exportToExcel(data, fileName, columns) {
  if (!data || data.length === 0) return

  const exportData = data.map(row => {
    const obj = {}
    if (columns) {
      columns.forEach(col => { obj[col.label] = row[col.prop] ?? '' })
    } else {
      Object.keys(row).forEach(k => { obj[k] = row[k] ?? '' })
    }
    return obj
  })

  const ws = XLSX.utils.json_to_sheet(exportData)
  ws['!cols'] = columns
    ? columns.map(c => ({ wch: Math.max(c.label.length * 2, 12) }))
    : Object.keys(exportData[0]).map(k => ({ wch: Math.max(k.length * 2, 12) }))

  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, ws, 'Sheet1')
  const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array' })
  saveAs(new Blob([buf], { type: 'application/octet-stream' }), fileName + '.xlsx')
}
