<template>
  <div class="dash">
    <!-- KPI Legend -->
    <div class="kpi-bar">
      <span class="kpi-bar-title">KPI 等级 · 采购总额门槛</span>
      <div class="kpi-tags">
        <span class="kt s">S 级 ≥ ¥100K → ¥15K</span>
        <span class="kt a">A 级 ≥ ¥50K → ¥12K</span>
        <span class="kt b">B 级 ≥ ¥20K → ¥9K</span>
        <span class="kt c">C 级 ≥ ¥5K → ¥7K</span>
        <span class="kt d">D 级 ＜ ¥5K → ¥5K</span>
      </div>
    </div>

    <!-- Row 1 -->
    <div class="dash-row">
      <div class="dash-card" style="flex:1.4">
        <div class="card-hd"><el-icon><DataAnalysis /></el-icon>员工 KPI 业绩对比<em>{{ kpiData.length }}人</em></div>
        <v-chart :option="kpiOption" style="height:370px" autoresize />
      </div>
      <div class="dash-card" style="flex:1">
        <div class="card-hd"><el-icon><DataLine /></el-icon>采购支出占比<em>总额 ¥{{ grandTotal }}</em></div>
        <v-chart :option="expendOption" style="height:370px" autoresize />
      </div>
    </div>

    <!-- Row 2 -->
    <div class="dash-row">
      <div class="dash-card" style="flex:1">
        <div class="card-hd"><el-icon><Goods /></el-icon>商品库占比（按供应商）</div>
        <v-chart :option="productOption" style="height:340px" autoresize />
      </div>
      <div class="dash-card" style="flex:1.5">
        <div class="card-hd"><el-icon><TrophyBase /></el-icon>KPI 评级明细</div>
        <el-table :data="kpiData" stripe size="small" max-height="340" class="kpi-table">
          <el-table-column type="index" label="#" width="42" />
          <el-table-column prop="name" label="姓名" width="80" />
          <el-table-column label="角色" width="72">
            <template #default="{row}"><span class="role-dot" :class="row.level===1?'admin':'user'"></span>{{ row.level===1?'管理员':'用户' }}</template>
          </el-table-column>
          <el-table-column label="KPI" width="60">
            <template #default="{row}"><span class="lv-badge" :class="row.kpiLevel">{{ row.kpiLevel }}</span></template>
          </el-table-column>
          <el-table-column label="采购次数" width="78" prop="purchaseCount" sortable />
          <el-table-column label="采购总额" width="130" sortable prop="purchaseTotal">
            <template #default="{row}"><span class="money">¥{{ (row.purchaseTotal||0).toLocaleString() }}</span></template>
          </el-table-column>
          <el-table-column label="当前薪资" width="100">
            <template #default="{row}">¥{{ (row.currentSalary||0).toLocaleString() }}</template>
          </el-table-column>
          <el-table-column label="建议薪资" width="100">
            <template #default="{row}"><span class="sugg">¥{{ (row.suggestedSalary||0).toLocaleString() }}</span></template>
          </el-table-column>
        </el-table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { use } from 'echarts/core'
import { CanvasRenderer } from 'echarts/renderers'
import { BarChart, PieChart } from 'echarts/charts'
import { GridComponent, TooltipComponent, LegendComponent } from 'echarts/components'
import VChart from 'vue-echarts'
import { getEmployeeKpi, getPurchaseExpenditure, getProductDistribution } from '../../api'

use([CanvasRenderer, BarChart, PieChart, GridComponent, TooltipComponent, LegendComponent])

const kpiData = ref([])
const expendData = ref({})
const productData = ref([])
const grandTotal = computed(() => (expendData.value.grandTotal||0).toLocaleString())

// KPI Bar
const kpiOption = computed(() => ({
  tooltip: {
    trigger:'axis', axisPointer:{type:'shadow'},
    formatter(p){const d=kpiData.value[p[0].dataIndex];return`<b>${d.name}</b><br/>总额:¥${d.purchaseTotal.toLocaleString()}<br/>次数:${d.purchaseCount}笔<br/>等级:<b>${d.kpiLevel}</b>`}
  },
  legend: { bottom:0, textStyle:{color:'#94a3b8',fontSize:11} },
  grid: { left:'3%',right:'8%',bottom:'14%',top:'6%',containLabel:true },
  xAxis: { type:'category',data:kpiData.value.map(d=>d.name),axisLabel:{color:'#64748b',fontSize:11},axisLine:{lineStyle:{color:'#e2e8f0'}} },
  yAxis: [
    { type:'value',name:'金额 ¥',nameTextStyle:{color:'#94a3b8',fontSize:10},axisLabel:{color:'#94a3b8',fontSize:10},splitLine:{lineStyle:{color:'#f1f5f9'}} },
    { type:'value',name:'次数',nameTextStyle:{color:'#94a3b8',fontSize:10},axisLabel:{color:'#94a3b8',fontSize:10},splitLine:{show:false} }
  ],
  series: [
    { name:'采购总额',type:'bar',data:kpiData.value.map(d=>d.purchaseTotal||0),barWidth:'36%',itemStyle:{borderRadius:[6,6,0,0],color:{type:'linear',x:0,y:0,x2:0,y2:1,colorStops:[{offset:0,color:'#818cf8'},{offset:1,color:'#6366f1'}]}},label:{show:true,position:'top',color:'#6366f1',fontSize:10,formatter:p=>p.value>0?'¥'+(p.value/1000).toFixed(0)+'k':''} },
    { name:'采购次数',type:'bar',data:kpiData.value.map(d=>d.purchaseCount||0),yAxisIndex:1,barWidth:'36%',itemStyle:{borderRadius:[6,6,0,0],color:'#fbbf24'},label:{show:true,position:'top',color:'#f59e0b',fontSize:10} }
  ]
}))

// Expenditure Pie
const expendOption = computed(() => {
  const d = Object.entries(expendData.value.byEmployee||{}).map(([n,v])=>({name:n,value:v}))
  return {
    tooltip:{trigger:'item',formatter:'{b}<br/>¥{c}'},
    legend:{orient:'vertical',right:8,top:'center',textStyle:{color:'#cbd5e1',fontSize:10},itemWidth:8,itemHeight:8,itemGap:6},
    series:[{type:'pie',radius:['48%','76%'],center:['40%','50%'],itemStyle:{borderRadius:5,borderColor:'#fff',borderWidth:2,opacity:.85},label:{show:false},emphasis:{label:{show:true,fontSize:13,fontWeight:'bold'}},data:d}]
  }
})

// Product Pie
const productOption = computed(() => ({
  tooltip:{trigger:'item',formatter:'{b}: {c} 件'},
  legend:{orient:'vertical',right:8,top:'center',textStyle:{color:'#cbd5e1',fontSize:10},itemWidth:8,itemHeight:8,itemGap:6},
  series:[{type:'pie',radius:['42%','74%'],center:['40%','50%'],itemStyle:{borderRadius:5,borderColor:'#fff',borderWidth:2,opacity:.85},label:{show:false},emphasis:{label:{show:true,fontSize:13,fontWeight:'bold'}},data:productData.value}]
}))

onMounted(async () => {
  try { const [a,b,c]=await Promise.all([getEmployeeKpi(),getPurchaseExpenditure(),getProductDistribution()]); kpiData.value=a.data||[]; expendData.value=b.data||{}; productData.value=c.data||[] } catch {}
})
</script>

<style scoped>
.dash { max-width:1320px; margin:0 auto; }

/* Entrance animation */
.dash-card {
  animation: cardEnter 0.5s ease both;
}
.dash-row:nth-child(2) .dash-card:nth-child(1) { animation-delay: 0.1s; }
.dash-row:nth-child(2) .dash-card:nth-child(2) { animation-delay: 0.2s; }
.dash-row:nth-child(3) .dash-card:nth-child(1) { animation-delay: 0.3s; }
.dash-row:nth-child(3) .dash-card:nth-child(2) { animation-delay: 0.4s; }

@keyframes cardEnter {
  from { opacity:0; transform: translateY(16px); }
  to { opacity:1; transform: translateY(0); }
}

.kpi-bar {
  display:flex; align-items:center; gap:20px; flex-wrap:wrap;
  background: var(--pms-bg-card); border-radius:12px; padding:12px 20px; margin-bottom:20px;
  border:1px solid var(--pms-border-color);
  animation: fadeUp 0.4s ease both;
}
@keyframes fadeUp { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }

.kpi-bar-title { font-size:13px; font-weight:600; color:var(--pms-text-tertiary); white-space:nowrap; }
.kpi-tags { display:flex; gap:10px; flex-wrap:wrap; }
.kt { font-size:11px; padding:3px 10px; border-radius:20px; font-weight:500; white-space:nowrap; transition: transform 0.2s; }
.kt:hover { transform: scale(1.08); }
.kt.s { background:#fef2f2; color:#dc2626; }
.kt.a { background: #fff7ed; color:#ea580c; }
.kt.b { background:#fefce8; color:#ca8a04; }
.kt.c { background:#f0fdf4; color:#16a34a; }
.kt.d { background:var(--pms-table-header-bg); color:var(--pms-text-placeholder); }

.dash-row { display:flex; gap:20px; margin-bottom:20px; }
.dash-card {
  background: var(--pms-bg-card); border-radius:14px; border:1px solid var(--pms-border-color);
  overflow:hidden; min-width:0;
  transition: all 0.3s ease;
}
.dash-card:hover { border-color:#c7d2fe; box-shadow: 0 4px 20px rgba(99,102,241,0.06); }
.card-hd {
  display:flex; align-items:center; gap:6px; padding:14px 18px;
  font-size:14px; font-weight:600; color:var(--pms-text-secondary);
  border-bottom:1px solid var(--pms-card-divider);
}
.card-hd .el-icon { color:var(--pms-accent-primary); }
.card-hd em { font-style:normal; font-size:12px; color:var(--pms-text-placeholder); margin-left:auto; }

/* KPI Table */
.kpi-table :deep(.el-table__header th) { background:var(--pms-table-header-bg); color:var(--pms-text-muted); font-weight:500; font-size:12px; }
.kpi-table :deep(.el-table__body tr) { transition: background 0.2s; }
.kpi-table :deep(.el-table__body tr:hover) { background: #eef2ff !important; }
.role-dot { display:inline-block; width:6px;height:6px;border-radius:50%;margin-right:5px;vertical-align:middle; animation: pulse 2s infinite; }
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
.role-dot.admin { background:var(--pms-accent-red); }
.role-dot.user { background:#22c55e; }
.lv-badge { display:inline-block;width:28px;height:20px;line-height:20px;text-align:center;border-radius:5px;font-size:11px;font-weight:700;color:#fff; transition: transform 0.2s; }
.lv-badge:hover { transform: scale(1.2); }
.lv-badge.S { background:var(--pms-accent-red); }
.lv-badge.A { background:#f97316; }
.lv-badge.B { background:#eab308;color:#333; }
.lv-badge.C { background:#22c55e; }
.lv-badge.D { background:#94a3b8; }
.money { font-weight:600;color:var(--pms-accent-primary); }
.sugg { font-weight:700;color:var(--pms-accent-green); }

@media (max-width:900px) { .dash-row { flex-direction:column; } }
</style>
