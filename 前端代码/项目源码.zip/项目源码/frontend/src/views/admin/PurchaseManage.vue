<template>
  <div class="admin-page">
    <div class="page-top">
      <div class="page-title">
        <div class="title-icon" style="--c:#06b6d4"><el-icon :size="22"><ShoppingCart /></el-icon></div>
        <div><h2>采购管理</h2><p>管理采购主表与明细</p></div>
      </div>
      <el-button type="primary" @click="openMainAdd"><el-icon><Plus /></el-icon>新增采购单</el-button>
    </div>

    <!-- Main table -->
    <div class="section-card">
      <div class="section-head"><span class="section-dot"></span>采购主表<em>{{ mainData.length }} 条</em></div>
      <el-table :data="mainData" stripe v-loading="mainLoading" highlight-current-row @current-change="handleMainSelect" style="width:100%">
        <el-table-column prop="purchaseNo" label="清单号" width="140" />
        <el-table-column label="采购员" width="120"><template #default="{row}">{{ row.employee?.name||'—' }}</template></el-table-column>
        <el-table-column label="数量" width="80"><template #default="{row}">{{ row.totalQuantity||0 }}</template></el-table-column>
        <el-table-column label="总价" width="130"><template #default="{row}"><span style="font-weight:600;color:var(--pms-accent-primary)">¥ {{ (row.totalPrice||0).toLocaleString() }}</span></template></el-table-column>
        <el-table-column label="状态" width="110">
          <template #default="{row}">
            <el-select :model-value="row.status" size="small" @change="(v)=>changeStatus(row.id,v)" style="width:100px">
              <el-option :value="0" label="草稿" />
              <el-option :value="1" label="待审批" />
              <el-option :value="2" label="已批准" />
              <el-option :value="3" label="已完成" />
              <el-option :value="4" label="已取消" />
            </el-select>
          </template>
        </el-table-column>
        <el-table-column prop="purchaseTime" label="采购时间" width="170" />
        <el-table-column prop="remark" label="备注" min-width="140" show-overflow-tooltip />
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click.stop="openMainEdit(row)">编辑</el-button>
            <el-popconfirm title="删除主表将级联删除明细！" @confirm="handleMainDelete(row.id)">
              <template #reference><el-button link type="danger">删除</el-button></template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <!-- Detail table -->
    <div class="section-card" v-if="selectedMain" style="margin-top:16px">
      <div class="section-head" style="--accent:var(--pms-accent-green)">
        <span class="section-dot" style="background:var(--pms-accent-green)"></span>
        明细 — {{ selectedMain.purchaseNo }}
        <em>{{ detailData.length }} 条</em>
        <el-button size="small" type="success" @click="openDetailAdd" style="margin-left:auto"><el-icon><Plus /></el-icon>添加明细</el-button>
      </div>
      <el-table :data="detailData" stripe v-loading="detailLoading" style="width:100%">
        <el-table-column prop="detailNo" label="明细号" width="100" />
        <el-table-column label="商品" width="180"><template #default="{row}">{{ row.product?.name||'—' }}</template></el-table-column>
        <el-table-column prop="quantity" label="数量" width="80" />
        <el-table-column label="单价" width="110"><template #default="{row}">¥ {{ row.unitPrice||0 }}</template></el-table-column>
        <el-table-column label="总价" width="120"><template #default="{row}"><span style="font-weight:600;color:var(--pms-accent-green)">¥ {{ (row.totalPrice||0).toLocaleString() }}</span></template></el-table-column>
        <el-table-column label="操作" width="150">
          <template #default="{ row }">
            <el-button link type="primary" @click="openDetailEdit(row)">编辑</el-button>
            <el-popconfirm title="删除该明细？" @confirm="handleDetailDelete(row.id)">
              <template #reference><el-button link type="danger">删除</el-button></template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <!-- Main Dialog -->
    <el-dialog :title="mainDialogTitle" v-model="mainDialogVisible" width="540px" @close="resetMainForm" destroy-on-close>
      <el-form :model="mainForm" :rules="mainRules" ref="mainFormRef" label-position="top">
        <el-form-item label="清单号" prop="purchaseNo"><el-input v-model="mainForm.purchaseNo" :disabled="mainIsEdit" /></el-form-item>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="采购员" prop="employeeId"><el-select v-model="mainForm.employeeId" style="width:100%"><el-option v-for="e in employees" :key="e.id" :label="e.name+'('+e.employeeNo+')'" :value="e.id" /></el-select></el-form-item></el-col>
          <el-col :span="6"><el-form-item label="数量"><el-input-number v-model="mainForm.totalQuantity" :min="0" style="width:100%" /></el-form-item></el-col>
          <el-col :span="6"><el-form-item label="总价"><el-input-number v-model="mainForm.totalPrice" :min="0" :precision="2" style="width:100%" /></el-form-item></el-col>
        </el-row>
        <el-form-item label="采购时间"><el-date-picker v-model="mainForm.purchaseTime" type="datetime" placeholder="选择时间" format="YYYY-MM-DD HH:mm:ss" value-format="YYYY-MM-DD HH:mm:ss" style="width:100%" /></el-form-item>
        <el-form-item label="备注"><el-input v-model="mainForm.remark" type="textarea" :rows="2" /></el-form-item>
      </el-form>
      <template #footer><el-button @click="mainDialogVisible=false">取消</el-button><el-button type="primary" :loading="mainSubmitting" @click="handleMainSubmit">保存</el-button></template>
    </el-dialog>

    <!-- Detail Dialog -->
    <el-dialog :title="detailDialogTitle" v-model="detailDialogVisible" width="500px" @close="resetDetailForm" destroy-on-close>
      <el-form :model="detailForm" :rules="detailRules" ref="detailFormRef" label-position="top">
        <el-form-item label="明细号"><el-input v-model="detailForm.detailNo" /></el-form-item>
        <el-form-item label="商品" prop="productId"><el-select v-model="detailForm.productId" style="width:100%"><el-option v-for="p in products" :key="p.id" :label="p.name+' (¥'+p.price+')'" :value="p.id" /></el-select></el-form-item>
        <el-row :gutter="16">
          <el-col :span="8"><el-form-item label="数量" prop="quantity"><el-input-number v-model="detailForm.quantity" :min="1" style="width:100%" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="单价"><el-input-number v-model="detailForm.unitPrice" :min="0" :precision="2" style="width:100%" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="总价"><el-input-number v-model="detailForm.totalPrice" :min="0" :precision="2" style="width:100%" /></el-form-item></el-col>
        </el-row>
        <el-form-item label="备注"><el-input v-model="detailForm.remark" /></el-form-item>
      </el-form>
      <template #footer><el-button @click="detailDialogVisible=false">取消</el-button><el-button type="primary" :loading="detailSubmitting" @click="handleDetailSubmit">保存</el-button></template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { getPurchaseMains, createPurchaseMain, updatePurchaseMain, deletePurchaseMain, getPurchaseDetails, createPurchaseDetail, updatePurchaseDetail, deletePurchaseDetail, getEmployees, getProducts, updatePurchaseStatus } from '../../api'

// Main
const mainData = ref([]), mainLoading = ref(false), selectedMain = ref(null)
const mainDialogVisible = ref(false), mainDialogTitle = ref(''), mainIsEdit = ref(false), mainEditId = ref(null), mainSubmitting = ref(false), mainFormRef = ref(null)
const employees = ref([])
const mainForm = reactive({ purchaseNo:'',employeeId:null,totalQuantity:0,totalPrice:0,purchaseTime:'',remark:'' })
const mainRules = { purchaseNo:[{required:true,message:'请输入'}], employeeId:[{required:true,message:'请选择'}] }

// Detail
const detailData = ref([]), detailLoading = ref(false), products = ref([])
const detailDialogVisible = ref(false), detailDialogTitle = ref(''), detailIsEdit = ref(false), detailEditId = ref(null), detailSubmitting = ref(false), detailFormRef = ref(null)
const detailForm = reactive({ detailNo:'',purchaseMainId:null,productId:null,quantity:1,unitPrice:0,totalPrice:0,remark:'' })
const detailRules = { productId:[{required:true,message:'请选择'}], quantity:[{required:true,message:'请输入'}] }

const loadMain = async () => { mainLoading.value=true; try{const r=await getPurchaseMains();mainData.value=r.data||[]}finally{mainLoading.value=false} }
const loadDetail = async () => { if(!selectedMain.value)return; detailLoading.value=true; try{const r=await getPurchaseDetails(selectedMain.value.id);detailData.value=r.data||[]}finally{detailLoading.value=false} }
const loadRefs = async () => { const [e,p]=await Promise.all([getEmployees(),getProducts()]); employees.value=e.data||[]; products.value=p.data||[] }

const handleMainSelect = (row) => { selectedMain.value = row; if(row)loadDetail(); else detailData.value=[] }

// Main CRUD
const resetMainForm = () => { Object.keys(mainForm).forEach(k=>mainForm[k]=(k==='totalQuantity'||k==='totalPrice')?0:(k==='employeeId'?null:'')); mainIsEdit.value=false; mainEditId.value=null; mainFormRef.value?.resetFields() }
const openMainAdd = () => { resetMainForm(); mainDialogTitle.value='新增采购单'; mainDialogVisible.value=true }
const openMainEdit = (row) => { resetMainForm(); mainDialogTitle.value='编辑采购单'; mainIsEdit.value=true; mainEditId.value=row.id; Object.assign(mainForm, {purchaseNo:row.purchaseNo,employeeId:row.employeeId,totalQuantity:row.totalQuantity,totalPrice:row.totalPrice,purchaseTime:row.purchaseTime,remark:row.remark}); mainDialogVisible.value=true }
const handleMainSubmit = async () => { if(!(await mainFormRef.value.validate().catch(()=>false)))return; mainSubmitting.value=true; try{if(mainIsEdit.value){await updatePurchaseMain(mainEditId.value,{...mainForm});ElMessage.success('已更新')}else{await createPurchaseMain({...mainForm});ElMessage.success('已新增')}mainDialogVisible.value=false;loadMain()}finally{mainSubmitting.value=false} }
const handleMainDelete = async (id) => { try{await deletePurchaseMain(id);ElMessage.success('已删除');if(selectedMain.value?.id===id)selectedMain.value=null;loadMain()}catch{} }

// Detail CRUD
const resetDetailForm = () => { Object.keys(detailForm).forEach(k=>detailForm[k]=k==='quantity'?1:(k==='unitPrice'||k==='totalPrice'?0:(k==='productId'?null:''))); detailIsEdit.value=false; detailEditId.value=null; detailFormRef.value?.resetFields() }
const openDetailAdd = () => { resetDetailForm(); detailDialogTitle.value='添加明细'; detailDialogVisible.value=true }
const openDetailEdit = (row) => { resetDetailForm(); detailDialogTitle.value='编辑明细'; detailIsEdit.value=true; detailEditId.value=row.id; Object.assign(detailForm, {detailNo:row.detailNo,productId:row.productId,quantity:row.quantity,unitPrice:row.unitPrice,totalPrice:row.totalPrice,remark:row.remark}); detailDialogVisible.value=true }
const handleDetailSubmit = async () => { if(!(await detailFormRef.value.validate().catch(()=>false)))return; detailSubmitting.value=true; try{const d={...detailForm,purchaseMainId:selectedMain.value.id}; if(detailIsEdit.value){await updatePurchaseDetail(detailEditId.value,d);ElMessage.success('已更新')}else{await createPurchaseDetail(d);ElMessage.success('已新增')}detailDialogVisible.value=false;loadDetail();loadMain()}finally{detailSubmitting.value=false} }
const handleDetailDelete = async (id) => { try{await deletePurchaseDetail(id);ElMessage.success('已删除');loadDetail();loadMain()}catch{} }

const changeStatus = async (id, newStatus) => {
  try {
    await updatePurchaseStatus(id, newStatus)
    const labels = ['草稿','待审批','已批准','已完成','已取消']
    ElMessage.success('状态已变更为: ' + labels[newStatus])
    loadMain()
  } catch {}
}

onMounted(() => { loadMain(); loadRefs() })
</script>

<style scoped>
.admin-page { max-width: 1200px; margin: 0 auto; }
.page-top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; flex-wrap: wrap; gap: 14px; }
.page-title { display: flex; align-items: center; gap: 14px; }
.title-icon { width: 44px; height: 44px; border-radius: 12px; background: color-mix(in srgb, var(--c) 10%, transparent); color: var(--c); display: flex; align-items: center; justify-content: center; }
.page-title h2 { font-size: 20px; margin: 0; color: var(--pms-text-primary); }
.page-title p { font-size: 13px; color: var(--pms-text-placeholder); margin: 2px 0 0; }
.section-card { background: var(--pms-bg-card); border-radius: 14px; overflow: hidden; border: 1px solid var(--pms-border-light); }
.section-head { display: flex; align-items: center; gap: 8px; padding: 14px 18px; font-weight: 600; font-size: 14px; color: var(--accent, var(--pms-accent-primary)); border-bottom: 1px solid var(--pms-border-subtle); }
.section-head em { font-weight: 400; font-size: 12px; color: var(--pms-text-placeholder); margin-left: 4px; font-style: normal; }
.section-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--pms-accent-primary); }
</style>
