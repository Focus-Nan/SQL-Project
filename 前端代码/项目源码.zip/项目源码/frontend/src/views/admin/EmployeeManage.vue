<template>
  <div class="admin-page">
    <div class="page-top">
      <div class="page-title">
        <div class="title-icon" style="--c:#f59e0b"><el-icon :size="22"><UserFilled /></el-icon></div>
        <div><h2>员工管理</h2><p>管理系统员工账户与权限</p></div>
      </div>
      <div class="page-actions">
        <el-button type="primary" @click="openAdd"><el-icon><Plus /></el-icon>新增</el-button>
        <el-button @click="openBatchImport"><el-icon><Upload /></el-icon>批量导入</el-button>
      </div>
    </div>

    <div class="mini-bar"><span class="mini-dot" style="background:#f59e0b"></span>共 <strong>{{ tableData.length }}</strong> 名员工</div>

    <div class="table-wrap">
      <el-table :data="tableData" stripe v-loading="loading" style="width:100%">
        <el-table-column label="员工" min-width="160">
          <template #default="{ row }">
            <div class="cell-entity">
              <el-avatar :size="36" :icon="UserFilled" />
              <div><strong>{{ row.name }}</strong></div>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="登录账号" width="150">
          <template #default="{ row }">
            <div class="cell-account">
              <code>{{ row.employeeNo }}</code>
              <el-button link size="small" @click="copyAccount(row)" title="复制账号">
                <el-icon><CopyDocument /></el-icon>
              </el-button>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="级别" width="110">
          <template #default="{ row }">
            <el-tag :type="row.level===1?'danger':'success'" effect="dark" size="small" round>{{ row.level===1?'管理员':'普通用户' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="phone" label="电话" width="130" />
        <el-table-column label="工资" width="120">
          <template #default="{ row }"><span style="font-weight:600;color:var(--pms-accent-green)">¥ {{ row.salary||'—' }}</span></template>
        </el-table-column>
        <el-table-column label="操作" width="230" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="openEdit(row)">编辑</el-button>
            <el-button link type="warning" @click="openResetPwd(row)">密码</el-button>
            <el-popconfirm title="确定删除？" @confirm="handleDelete(row.id)">
              <template #reference><el-button link type="danger">删除</el-button></template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <el-dialog :title="dialogTitle" v-model="dialogVisible" width="560px" @close="resetForm" destroy-on-close>
      <el-form :model="form" :rules="rules" ref="formRef" label-position="top">
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="员工编号" prop="employeeNo"><el-input v-model="form.employeeNo" :disabled="isEdit" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="姓名" prop="name"><el-input v-model="form.name" /></el-form-item></el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="密码" :prop="isEdit?'':'password'"><el-input v-model="form.password" type="password" show-password :placeholder="isEdit?'留空不修改':''" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="级别" prop="level"><el-select v-model="form.level" style="width:100%"><el-option label="管理员" :value="1" /><el-option label="普通用户" :value="2" /></el-select></el-form-item></el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="电话"><el-input v-model="form.phone" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="工资"><el-input-number v-model="form.salary" :min="0" :precision="2" style="width:100%" /></el-form-item></el-col>
        </el-row>
        <el-form-item label="备注"><el-input v-model="form.remark" type="textarea" :rows="2" /></el-form-item>
      </el-form>
      <template #footer><el-button @click="dialogVisible=false">取消</el-button><el-button type="primary" :loading="submitting" @click="handleSubmit">保存</el-button></template>
    </el-dialog>

    <el-dialog title="批量导入" v-model="batchVisible" width="650px" destroy-on-close>
      <el-alert type="info" :closable="false" style="margin-bottom:16px">
        <template #title>格式：<code>编号|姓名|密码|级别(1/2)|电话|工资|备注</code>（前4项必填）</template>
      </el-alert>
      <el-input v-model="batchData" type="textarea" :rows="10" placeholder="每行一条记录..." />
      <template #footer><el-button @click="batchVisible=false">取消</el-button><el-button type="primary" :loading="batchLoading" @click="handleBatchImport">导入</el-button></template>
    </el-dialog>

    <!-- Reset Password Dialog -->
    <el-dialog title="重置密码" v-model="pwdVisible" width="420px" destroy-on-close @close="pwdForm.password=''">
      <div style="margin-bottom:12px">为 <strong>{{ pwdTarget?.name }}</strong>（{{ pwdTarget?.employeeNo }}）设置新密码</div>
      <el-input v-model="pwdForm.password" type="text" show-password placeholder="输入新密码" maxlength="50">
        <template #prefix><el-icon><Lock /></el-icon></template>
      </el-input>
      <div style="margin-top:8px;font-size:12px;color:var(--pms-text-placeholder)">密码将以加密方式存储，管理员无法查看原始密码</div>
      <template #footer>
        <el-button @click="pwdVisible=false">取消</el-button>
        <el-button type="primary" :loading="pwdSubmitting" :disabled="!pwdForm.password" @click="handleResetPwd">确认重置</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { getEmployees, createEmployee, updateEmployee, deleteEmployee, batchImportEmployees, resetEmployeePassword } from '../../api'

const tableData = ref([]), loading = ref(false), submitting = ref(false)
const dialogVisible = ref(false), dialogTitle = ref('新增员工'), isEdit = ref(false), editId = ref(null), formRef = ref(null)

const form = reactive({ employeeNo:'',name:'',password:'',level:2,phone:'',salary:null,remark:'' })
const rules = {
  employeeNo: [{ required: true, message: '请输入编号' }],
  name: [{ required: true, message: '请输入姓名' }],
  password: [{ required: true, message: '请输入密码' }],
  level: [{ required: true, message: '请选择' }]
}
const batchVisible = ref(false), batchData = ref(''), batchLoading = ref(false)

// Reset password
const pwdVisible = ref(false), pwdTarget = ref(null), pwdSubmitting = ref(false)
const pwdForm = reactive({ password: '' })

const loadData = async () => { loading.value = true; try { const r = await getEmployees(); tableData.value = r.data || [] } finally { loading.value = false } }

const resetForm = () => { Object.keys(form).forEach(k=>form[k]=k==='level'?2:(k==='salary'?null:'')); isEdit.value=false; editId.value=null; formRef.value?.resetFields() }
const openAdd = () => { resetForm(); dialogTitle.value='新增员工'; dialogVisible.value=true }
const openEdit = (row) => { resetForm(); dialogTitle.value='编辑员工'; isEdit.value=true; editId.value=row.id; form.employeeNo=row.employeeNo; form.name=row.name; form.password=''; form.level=row.level; form.phone=row.phone; form.salary=row.salary; form.remark=row.remark; dialogVisible.value=true }

const handleSubmit = async () => {
  const fs = { ...rules }
  if (isEdit.value) delete fs.password  // password not required on edit
  if (!(await formRef.value.validate().catch(()=>false))) return
  submitting.value = true
  try {
    if (isEdit.value) { await updateEmployee(editId.value,{...form}); ElMessage.success('已更新') }
    else { await createEmployee({...form}); ElMessage.success('已新增') }
    dialogVisible.value = false; loadData()
  } finally { submitting.value = false }
}

const handleDelete = async (id) => { try { await deleteEmployee(id); ElMessage.success('已删除'); loadData() } catch {} }
const copyAccount = (row) => { navigator.clipboard.writeText(row.employeeNo).then(()=>ElMessage.success('账号已复制')).catch(()=>ElMessage.warning('复制失败')) }
const openResetPwd = (row) => { pwdTarget.value = row; pwdForm.password = ''; pwdVisible.value = true }
const handleResetPwd = async () => {
  if (!pwdForm.password) return
  pwdSubmitting.value = true
  try { await resetEmployeePassword(pwdTarget.value.id, pwdForm.password); ElMessage.success('密码已重置'); pwdVisible.value = false; pwdTarget.value = null }
  finally { pwdSubmitting.value = false }
}
const openBatchImport = () => { batchData.value=''; batchVisible.value=true }
const handleBatchImport = async () => {
  if (!batchData.value.trim()) { ElMessage.warning('请输入数据'); return }
  batchLoading.value = true
  try { const r = await batchImportEmployees(batchData.value); ElMessage.success(`导入 ${r.data?.length||0} 条`); batchVisible.value=false; loadData() }
  finally { batchLoading.value = false }
}

onMounted(loadData)
</script>

<style scoped>
.admin-page { max-width: 1200px; margin: 0 auto; }
.page-top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px; flex-wrap: wrap; gap: 14px; }
.page-title { display: flex; align-items: center; gap: 14px; }
.title-icon { width: 44px; height: 44px; border-radius: 12px; background: color-mix(in srgb, var(--c) 10%, transparent); color: var(--c); display: flex; align-items: center; justify-content: center; }
.page-title h2 { font-size: 20px; margin: 0; color: var(--pms-text-primary); }
.page-title p { font-size: 13px; color: var(--pms-text-placeholder); margin: 2px 0 0; }
.page-actions { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.search-box { width: 210px; }
.mini-bar { font-size: 13px; color: var(--pms-text-muted); margin-bottom: 10px; display: flex; align-items: center; gap: 6px; }
.mini-dot { width: 8px; height: 8px; border-radius: 50%; }
.table-wrap { background: var(--pms-bg-card); border-radius: 14px; overflow: hidden; border: 1px solid var(--pms-border-light); }
.cell-entity { display: flex; align-items: center; gap: 10px; }
.cell-entity small { color: var(--pms-text-placeholder); }
.cell-account { display:flex; align-items:center; gap:4px; }
.cell-account code { background:var(--pms-bg-hover); padding:2px 8px; border-radius:4px; font-size:12px; color:var(--pms-accent-primary); }
</style>
