<template>
  <div class="admin-page">
    <div class="page-top">
      <div class="page-title">
        <div class="title-icon" style="--c:#10b981"><el-icon :size="22"><Goods /></el-icon></div>
        <div><h2>商品管理</h2><p>管理商品信息，关联供应商</p></div>
      </div>
      <div class="page-actions">
        <el-input v-model="search" placeholder="搜索编号/名称" clearable class="search-box" @clear="loadData" @keyup.enter="loadData">
          <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-button type="primary" @click="openAdd"><el-icon><Plus /></el-icon>新增</el-button>
        <el-button @click="openBatchImport"><el-icon><Upload /></el-icon>批量导入</el-button>
        <el-button @click="exportProducts"><el-icon><Download /></el-icon>导出Excel</el-button>
      </div>
    </div>

    <div class="mini-bar"><span class="mini-dot" style="background:#10b981"></span>共 <strong>{{ tableData.length }}</strong> 件商品</div>

    <div class="table-wrap">
      <el-table :data="tableData" stripe v-loading="loading" style="width:100%">
        <el-table-column prop="productNo" label="编号" width="110" />
        <el-table-column label="商品" min-width="200">
          <template #default="{ row }">
            <div class="cell-entity">
              <div class="prod-avatar">
                <img v-if="row.image" :src="row.image" @error="$event.target.style.display='none'" />
                <el-icon v-else :size="20"><Goods /></el-icon>
              </div>
              <div><strong>{{ row.name }}</strong><br><small>{{ row.description || '暂无简介' }}</small></div>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="单价" width="110" sortable prop="price">
          <template #default="{ row }"><span class="price-tag">¥ {{ row.price }}</span></template>
        </el-table-column>
        <el-table-column label="供应商" width="150">
          <template #default="{ row }"><el-tag size="small" effect="plain">{{ row.supplier?.name || '—' }}</el-tag></template>
        </el-table-column>
        <el-table-column label="库存" width="100">
          <template #default="{ row }">
            <span :style="{color:(row.stockQuantity||0)<=(row.safetyStock||10)?'#ef4444':'#10b981',fontWeight:'600'}">
              {{ row.stockQuantity||0 }}
            </span>
          </template>
        </el-table-column>
        <el-table-column label="安全库存" width="90" prop="safetyStock" />
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="openEdit(row)">编辑</el-button>
            <el-popconfirm title="确定删除？" @confirm="handleDelete(row.id)">
              <template #reference><el-button link type="danger">删除</el-button></template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <el-dialog :title="dialogTitle" v-model="dialogVisible" width="560px" @close="resetForm" destroy-on-close>
      <el-form :model="form" :rules="rules" ref="formRef" label-position="top">
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="编号" prop="productNo"><el-input v-model="form.productNo" :disabled="isEdit" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="名称" prop="name"><el-input v-model="form.name" /></el-form-item></el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="单价" prop="price"><el-input-number v-model="form.price" :min="0" :precision="2" style="width:100%" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="供应商"><el-select v-model="form.supplierId" placeholder="选择供应商" clearable style="width:100%"><el-option v-for="s in suppliers" :key="s.id" :label="s.name" :value="s.id" /></el-select></el-form-item></el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="当前库存"><el-input-number v-model="form.stockQuantity" :min="0" style="width:100%" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="安全库存"><el-input-number v-model="form.safetyStock" :min="0" style="width:100%" /></el-form-item></el-col>
        </el-row>
        <el-form-item label="图片URL"><el-input v-model="form.image" placeholder="输入商品图片链接" /></el-form-item>
        <el-form-item label="简介"><el-input v-model="form.description" type="textarea" :rows="2" /></el-form-item>
        <el-form-item label="备注"><el-input v-model="form.remark" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="handleSubmit">保存</el-button>
      </template>
    </el-dialog>

    <el-dialog title="批量导入" v-model="batchVisible" width="650px" destroy-on-close>
      <el-alert type="info" :closable="false" style="margin-bottom:16px">
        <template #title>
          格式：<code>编号|名称|单价|供应商|简介|备注</code>（编号+名称+单价必填）<br/>
          <small>支持竖线、逗号、Tab 分隔。供应商可填ID或<strong>名称</strong>（自动匹配）。例：<code>P006|测试商品|99|华为|测试</code></small>
        </template>
      </el-alert>
      <el-input v-model="batchData" type="textarea" :rows="10" placeholder="每行一条记录..." />
      <template #footer><el-button @click="batchVisible=false">取消</el-button><el-button type="primary" :loading="batchLoading" @click="handleBatchImport">导入</el-button></template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { getProducts, createProduct, updateProduct, deleteProduct, batchImportProducts, getSuppliers } from '../../api'
import { exportToExcel } from '../../utils/excel'

const search = ref(''), tableData = ref([]), suppliers = ref([])
const loading = ref(false), submitting = ref(false)
const dialogVisible = ref(false), dialogTitle = ref('新增商品'), isEdit = ref(false), editId = ref(null), formRef = ref(null)

const form = reactive({ productNo:'',name:'',price:null,supplierId:null,stockQuantity:0,safetyStock:10,image:'',description:'',remark:'' })
const rules = {
  productNo: [{ required: true, message: '请输入编号' }],
  name: [{ required: true, message: '请输入名称' }],
  price: [{ required: true, message: '请输入单价' }]
}
const batchVisible = ref(false), batchData = ref(''), batchLoading = ref(false)

const loadData = async () => {
  loading.value = true
  try { const r = await getProducts(search.value || undefined); tableData.value = r.data || [] } finally { loading.value = false }
}
const loadSuppliers = async () => { const r = await getSuppliers(); suppliers.value = r.data || [] }

const resetForm = () => { form.productNo='';form.name='';form.price=null;form.supplierId=null;form.stockQuantity=0;form.safetyStock=10;form.image='';form.description='';form.remark=''; isEdit.value=false; editId.value=null; formRef.value?.resetFields() }
const openAdd = () => { resetForm(); dialogTitle.value='新增商品'; dialogVisible.value=true }
const openEdit = (row) => { resetForm(); dialogTitle.value='编辑商品'; isEdit.value=true; editId.value=row.id; form.productNo=row.productNo; form.name=row.name; form.price=row.price; form.supplierId=row.supplierId; form.stockQuantity=row.stockQuantity||0; form.safetyStock=row.safetyStock||10; form.image=row.image||''; form.description=row.description; form.remark=row.remark; dialogVisible.value=true }

const handleSubmit = async () => {
  if (!(await formRef.value.validate().catch(()=>false))) return
  submitting.value = true
  try {
    if (isEdit.value) { await updateProduct(editId.value,{...form}); ElMessage.success('已更新') }
    else { await createProduct({...form}); ElMessage.success('已新增') }
    dialogVisible.value = false; loadData()
  } finally { submitting.value = false }
}

const handleDelete = async (id) => { try { await deleteProduct(id); ElMessage.success('已删除'); loadData() } catch {} }
const openBatchImport = () => { batchData.value=''; batchVisible.value=true }
const handleBatchImport = async () => {
  if (!batchData.value.trim()) { ElMessage.warning('请输入数据'); return }
  batchLoading.value = true
  try { const r = await batchImportProducts(batchData.value); ElMessage.success(`导入 ${r.data?.length||0} 条`); batchVisible.value=false; loadData() }
  finally { batchLoading.value = false }
}

const exportProducts = () => {
  exportToExcel(tableData.value, '商品列表', [
    { prop: 'productNo', label: '商品编号' },
    { prop: 'name', label: '商品名称' },
    { prop: 'price', label: '单价' },
    { prop: 'description', label: '简介' },
    { prop: 'stockQuantity', label: '库存' },
    { prop: 'safetyStock', label: '安全库存' },
  ])
}

onMounted(() => { loadData(); loadSuppliers() })
</script>

<style scoped>
.admin-page { max-width: 1200px; margin: 0 auto; }
.page-top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px; flex-wrap: wrap; gap: 14px; }
.page-title { display: flex; align-items: center; gap: 14px; }
.title-icon { width: 44px; height: 44px; border-radius: 12px; background: color-mix(in srgb, var(--c) 10%, transparent); color: var(--c); display: flex; align-items: center; justify-content: center; }
.page-title h2 { font-size: 20px; margin: 0; color: var(--pms-text-primary); }
.page-title p { font-size: 13px; color: var(--pms-text-placeholder); margin: 2px 0 0; }
.page-actions { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.search-box { width: 210px; }
.mini-bar { font-size: 13px; color: var(--pms-text-muted); margin-bottom: 10px; display: flex; align-items: center; gap: 6px; }
.mini-dot { width: 8px; height: 8px; border-radius: 50%; }
.table-wrap { background: var(--pms-bg-card); border-radius: 14px; overflow: hidden; border: 1px solid var(--pms-border-light); }
.cell-entity { display: flex; align-items: center; gap: 10px; }
.cell-entity small { color: var(--pms-text-placeholder); }
.prod-avatar { width: 40px; height: 40px; border-radius: 10px; background: linear-gradient(135deg, color-mix(in srgb, var(--pms-accent-green) 12%, var(--pms-bg-card)), color-mix(in srgb, var(--pms-accent-green) 18%, var(--pms-bg-card))); color: var(--pms-accent-green); display: flex; align-items: center; justify-content: center; overflow:hidden; }
.prod-avatar img { width:100%;height:100%;object-fit:cover; }
.price-tag { font-weight: 600; color: var(--pms-accent-red); }
</style>
