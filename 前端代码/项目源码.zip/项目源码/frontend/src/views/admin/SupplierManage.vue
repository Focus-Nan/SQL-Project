<template>
  <div class="admin-page">
    <!-- Page Header -->
    <div class="page-top">
      <div class="page-title">
        <div class="title-icon" style="--c:#6366f1"><el-icon :size="22"><OfficeBuilding /></el-icon></div>
        <div>
          <h2>供应商管理</h2>
          <p>管理供应商信息，支持批量导入</p>
        </div>
      </div>
      <div class="page-actions">
        <el-input v-model="search" placeholder="搜索编号/名称" clearable class="search-box" @clear="loadData" @keyup.enter="loadData">
          <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-button type="primary" @click="openAdd"><el-icon><Plus /></el-icon>新增</el-button>
        <el-button @click="openBatchImport"><el-icon><Upload /></el-icon>批量导入</el-button>
        <el-button @click="exportSuppliers"><el-icon><Download /></el-icon>导出Excel</el-button>
      </div>
    </div>

    <!-- Stats -->
    <div class="mini-bar"><span class="mini-dot"></span>共 <strong>{{ tableData.length }}</strong> 家供应商</div>

    <!-- Table -->
    <div class="table-wrap">
      <el-table :data="tableData" stripe v-loading="loading" style="width:100%">
        <el-table-column prop="supplierNo" label="编号" width="110" />
        <el-table-column label="供应商" min-width="200">
          <template #default="{ row }">
            <div class="cell-entity">
              <el-avatar :size="36" icon="OfficeBuilding" />
              <div><strong>{{ row.name }}</strong><br><small>{{ row.shortName || '—' }}</small></div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="contactPerson" label="联系人" width="100" />
        <el-table-column prop="phone" label="电话" width="130" />
        <el-table-column prop="email" label="邮箱" width="170" show-overflow-tooltip />
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="openEdit(row)">编辑</el-button>
            <el-popconfirm title="确定删除？" @confirm="handleDelete(row.id)">
              <template #reference><el-button link type="danger">删除</el-button></template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <!-- Add/Edit Dialog -->
    <el-dialog :title="dialogTitle" v-model="dialogVisible" width="620px" @close="resetForm" destroy-on-close>
      <el-form :model="form" :rules="rules" ref="formRef" label-width="100px" label-position="top">
        <el-row :gutter="16">
          <el-col :span="8"><el-form-item label="编号" prop="supplierNo"><el-input v-model="form.supplierNo" :disabled="isEdit" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="名称" prop="name"><el-input v-model="form.name" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="简称"><el-input v-model="form.shortName" /></el-form-item></el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="地址"><el-input v-model="form.address" /></el-form-item></el-col>
          <el-col :span="6"><el-form-item label="电话"><el-input v-model="form.phone" /></el-form-item></el-col>
          <el-col :span="6"><el-form-item label="邮箱"><el-input v-model="form.email" /></el-form-item></el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="8"><el-form-item label="联系人"><el-input v-model="form.contactPerson" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="联系人电话"><el-input v-model="form.contactPhone" /></el-form-item></el-col>
        </el-row>
        <el-form-item label="备注"><el-input v-model="form.remark" type="textarea" :rows="2" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="handleSubmit">保存</el-button>
      </template>
    </el-dialog>

    <!-- Batch Import Dialog -->
    <el-dialog title="批量导入" v-model="batchVisible" width="650px" destroy-on-close>
      <el-alert type="info" :closable="false" style="margin-bottom:16px">
        <template #title>格式：<code>编号|名称|简称|地址|电话|邮箱|联系人|联系人电话|备注</code>（编号+名称必填）</template>
      </el-alert>
      <el-input v-model="batchData" type="textarea" :rows="10" placeholder="每行一条记录..." />
      <template #footer>
        <el-button @click="batchVisible = false">取消</el-button>
        <el-button type="primary" :loading="batchLoading" @click="handleBatchImport">导入</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { getSuppliers, createSupplier, updateSupplier, deleteSupplier, batchImportSuppliers } from '../../api'
import { exportToExcel } from '../../utils/excel'

const search = ref('')
const tableData = ref([])
const loading = ref(false)
const submitting = ref(false)
const dialogVisible = ref(false)
const dialogTitle = ref('新增供应商')
const isEdit = ref(false)
const editId = ref(null)
const formRef = ref(null)

const form = reactive({ supplierNo:'',name:'',shortName:'',address:'',phone:'',email:'',contactPerson:'',contactPhone:'',remark:'' })
const rules = {
  supplierNo: [{ required: true, message: '请输入编号' }],
  name: [{ required: true, message: '请输入名称' }]
}

const batchVisible = ref(false), batchData = ref(''), batchLoading = ref(false)

const loadData = async () => {
  loading.value = true
  try { const r = await getSuppliers(search.value || undefined); tableData.value = r.data || [] }
  finally { loading.value = false }
}

const resetForm = () => { Object.keys(form).forEach(k=>form[k]=''); isEdit.value=false; editId.value=null; formRef.value?.resetFields() }
const openAdd = () => { resetForm(); dialogTitle.value='新增供应商'; dialogVisible.value=true }
const openEdit = (row) => { resetForm(); dialogTitle.value='编辑供应商'; isEdit.value=true; editId.value=row.id; Object.assign(form, row); dialogVisible.value=true }

const handleSubmit = async () => {
  if (!(await formRef.value.validate().catch(()=>false))) return
  submitting.value = true
  try {
    if (isEdit.value) { await updateSupplier(editId.value,{...form}); ElMessage.success('已更新') }
    else { await createSupplier({...form}); ElMessage.success('已新增') }
    dialogVisible.value = false; loadData()
  } finally { submitting.value = false }
}

const handleDelete = async (id) => { try { await deleteSupplier(id); ElMessage.success('已删除'); loadData() } catch {} }
const openBatchImport = () => { batchData.value = ''; batchVisible.value = true }

const handleBatchImport = async () => {
  if (!batchData.value.trim()) { ElMessage.warning('请输入数据'); return }
  batchLoading.value = true
  try { const r = await batchImportSuppliers(batchData.value); ElMessage.success(`导入 ${r.data?.length||0} 条`); batchVisible.value = false; loadData() }
  finally { batchLoading.value = false }
}

const exportSuppliers = () => {
  exportToExcel(tableData.value, '供应商列表', [
    { prop: 'supplierNo', label: '编号' },
    { prop: 'name', label: '名称' },
    { prop: 'shortName', label: '简称' },
    { prop: 'contactPerson', label: '联系人' },
    { prop: 'phone', label: '电话' },
    { prop: 'email', label: '邮箱' },
    { prop: 'address', label: '地址' },
  ])
}

onMounted(loadData)
</script>

<style scoped>
.admin-page { max-width: 1200px; margin: 0 auto; }
.page-top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px; flex-wrap: wrap; gap: 14px; }
.page-title { display: flex; align-items: center; gap: 14px; }
.title-icon { width: 44px; height: 44px; border-radius: 12px; background: color-mix(in srgb, var(--c) 10%, transparent); color: var(--c); display: flex; align-items: center; justify-content: center; }
.page-title h2 { font-size: 20px; margin: 0; color: var(--pms-text-primary); }
.page-title p { font-size: 13px; color: var(--pms-text-placeholder); margin: 2px 0 0; }
.page-actions { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.search-box { width: 210px; }
.mini-bar { font-size: 13px; color: var(--pms-text-muted); margin-bottom: 10px; display: flex; align-items: center; gap: 6px; }
.mini-dot { width: 8px; height: 8px; background: var(--pms-accent-primary); border-radius: 50%; }
.table-wrap { background: var(--pms-bg-card); border-radius: 14px; overflow: hidden; border: 1px solid var(--pms-border-light); }
.cell-entity { display: flex; align-items: center; gap: 10px; }
.cell-entity small { color: var(--pms-text-placeholder); }
</style>
