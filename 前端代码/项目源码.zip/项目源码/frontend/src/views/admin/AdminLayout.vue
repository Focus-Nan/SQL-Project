<template>
  <div class="admin-shell">
    <!-- Sidebar -->
    <aside class="sidebar" :class="{ collapsed: isCollapse }">
      <div class="sb-brand" @click="$router.push('/admin/dashboard')">
        <div class="sb-logo"><el-icon :size="22"><ShoppingCart /></el-icon></div>
        <transition name="fade"><span v-show="!isCollapse" class="sb-title">采购管理</span></transition>
      </div>

      <nav class="sb-nav">
        <router-link to="/admin/dashboard" class="sb-item" exact-active-class="active">
          <el-icon><DataAnalysis /></el-icon><span>首页看板</span>
        </router-link>
        <router-link to="/admin/suppliers" class="sb-item" active-class="active">
          <el-icon><OfficeBuilding /></el-icon><span>供应商</span>
        </router-link>
        <router-link to="/admin/products" class="sb-item" active-class="active">
          <el-icon><Goods /></el-icon><span>商品管理</span>
        </router-link>
        <router-link to="/admin/employees" class="sb-item" active-class="active">
          <el-icon><UserFilled /></el-icon><span>员工管理</span>
        </router-link>
        <router-link to="/admin/purchases" class="sb-item" active-class="active">
          <el-icon><ShoppingCart /></el-icon><span>采购管理</span>
        </router-link>
      </nav>

      <div class="sb-footer">
        <button class="sb-collapse-btn" @click="isCollapse=!isCollapse">
          <el-icon :size="16"><component :is="isCollapse?'Expand':'Fold'" /></el-icon>
        </button>
      </div>
    </aside>

    <!-- Main -->
    <div class="main-area">
      <header class="topbar">
        <div class="tb-left">
          <el-breadcrumb separator="·">
            <el-breadcrumb-item :to="{path:'/admin/dashboard'}">首页</el-breadcrumb-item>
            <el-breadcrumb-item v-if="pageTitle">{{ pageTitle }}</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <div class="tb-right">
          <span class="tb-clock">{{ nowTime }}</span>
          <ThemeToggle />
          <div class="tb-user">
            <label class="avatar-upload-btn" title="点击更换头像">
              <input type="file" accept="image/*" hidden @change="onAvatarChange" />
              <el-avatar :size="32" :src="avatarSrc" icon="UserFilled">
                <el-icon class="avatar-overlay"><Camera /></el-icon>
              </el-avatar>
            </label>
            <span>{{ userStore.userInfo?.name }}</span>
          </div>
          <el-button text circle class="tb-logout" @click="handleLogout" title="退出">
            <el-icon :size="17"><SwitchButton /></el-icon>
          </el-button>
        </div>
      </header>

      <main class="content">
        <router-view />
      </main>
    </div>
  </div>
</template>

<script setup>
import { computed, ref, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '../../store/user'
import { ElMessageBox, ElMessage } from 'element-plus'
import { uploadAvatar } from '../../api'
import ThemeToggle from '../../components/ThemeToggle.vue'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const isCollapse = ref(false)
const nowTime = ref('')

const pageTitle = computed(() => {
  const m = { dashboard:'首页看板', suppliers:'供应商管理', products:'商品管理', employees:'员工管理', purchases:'采购管理' }
  return m[route.path.split('/').pop()] || ''
})

let t = null
onMounted(() => { const u=()=>{const d=new Date();nowTime.value=d.toLocaleTimeString('zh-CN',{hour12:false})};u();t=setInterval(u,1000) })
onUnmounted(() => clearInterval(t))

const handleLogout = async () => {
  try { await ElMessageBox.confirm('确定退出？','',{type:'warning',confirmButtonText:'退出',cancelButtonText:'取消'}); userStore.logout(); router.push('/login') } catch {}
}

const avatarSrc = computed(() => userStore.userInfo?.avatar || '')
const onAvatarChange = async (e) => {
  const file = e.target.files[0]
  if (!file) return
  if (file.size > 2 * 1024 * 1024) { ElMessage.warning('图片不能超过2MB'); return }
  const reader = new FileReader()
  reader.onload = async () => {
    try {
      await uploadAvatar(reader.result)
      userStore.setAvatar(reader.result)
      ElMessage.success('头像已更新')
    } catch {}
  }
  reader.readAsDataURL(file)
  e.target.value = ''
}
</script>

<style scoped>
.admin-shell { display:flex; height:100vh; background:var(--pms-bg-page); }

/* Sidebar */
.sidebar {
  width:220px; flex-shrink:0; background:var(--pms-sidebar-bg);
  display:flex; flex-direction:column;
  transition: width 0.25s ease;
  overflow:hidden;
}
.sidebar.collapsed { width:64px; }
.sb-brand {
  display:flex; align-items:center; gap:10px; padding:0 18px; height:56px;
  cursor:pointer; border-bottom:1px solid var(--pms-sidebar-border);
}
.sb-logo {
  width:34px;height:34px;border-radius:10px;background:linear-gradient(135deg,#6366f1,#8b5cf6);
  display:flex;align-items:center;justify-content:center;color:#fff;flex-shrink:0;
}
.sb-title { color:#fff;font-size:16px;font-weight:600;white-space:nowrap;letter-spacing:.5px; }

.sb-nav { flex:1; padding:12px 8px; display:flex; flex-direction:column; gap:2px; }
.sb-item {
  display:flex; align-items:center; gap:10px; padding:0 14px; height:42px;
  border-radius:10px; color:var(--pms-sidebar-text); text-decoration:none;
  font-size:14px; transition:all 0.15s; white-space:nowrap; overflow:hidden;
}
.sb-item:hover { background:rgba(255,255,255,0.06); color:var(--pms-sidebar-text-hover); }
.sb-item.active { background:var(--pms-sidebar-active-bg); color:var(--pms-sidebar-active-text); font-weight:500; }
.sb-item .el-icon { font-size:18px; flex-shrink:0; }

.sb-footer { padding:8px; border-top:1px solid var(--pms-sidebar-border); }
.sb-collapse-btn {
  width:100%; height:36px; border:none; border-radius:8px; background:transparent;
  color:var(--pms-sidebar-collapse); cursor:pointer; display:flex; align-items:center; justify-content:center;
}
.sb-collapse-btn:hover { background:rgba(255,255,255,0.06); color:var(--pms-sidebar-collapse-hover); }

/* Topbar */
.main-area { flex:1; display:flex; flex-direction:column; min-width:0; }
.topbar {
  height:56px; background:var(--pms-bg-card); border-bottom:1px solid var(--pms-border-color);
  display:flex; align-items:center; justify-content:space-between;
  padding:0 24px; flex-shrink:0;
}
.tb-right { display:flex; align-items:center; gap:16px; }
.tb-clock { font-size:13px; color:var(--pms-text-placeholder); font-variant-numeric:tabular-nums; }
.tb-user { display:flex; align-items:center; gap:8px; font-size:14px; color:var(--pms-text-secondary); }
.avatar-upload-btn { cursor:pointer; position:relative; display:flex; }
.avatar-upload-btn:hover .avatar-overlay { opacity:1; }
.avatar-overlay {
  position:absolute; inset:0; display:flex; align-items:center; justify-content:center;
  background:rgba(0,0,0,0.4); border-radius:50%; opacity:0; transition:opacity 0.2s;
  color:#fff; font-size:14px;
}
.tb-logout { color:var(--pms-text-placeholder); }
.tb-logout:hover { color:var(--pms-accent-red); }

/* Content */
.content { flex:1; overflow-y:auto; padding:24px; }

.fade-enter-active,.fade-leave-active { transition:opacity 0.2s; }
.fade-enter-from,.fade-leave-to { opacity:0; }
</style>
