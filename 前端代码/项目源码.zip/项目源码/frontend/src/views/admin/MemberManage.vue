<template>
  <div class="admin-page">
    <div class="page-top">
      <div class="page-title">
        <div class="title-icon" style="--c:#ec4899"><el-icon :size="22"><Avatar /></el-icon></div>
        <div><h2>会员管理</h2><p>管理会员信息与折扣率</p></div>
      </div>
      <div class="page-actions">
        <el-input v-model="search" placeholder="搜索编号/姓名" clearable class="search-box" @clear="loadData" @keyup.enter="loadData">
          <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-button type="primary" @click="openAdd"><el-icon><Plus /></el-icon>新增</el-button>
        <el-button @click="openBatchImport"><el-icon><Upload /></el-icon>批量导入</el-button>
      </div>
    </div>

    <div class="mini-bar"><span class="mini-dot" style="background:#ec4899"></span>共 <strong>{{ tableData.length }}</strong> 名会员</div>

    <div class="table-wrap">
      <el-table :data="tableData" stripe v-loading="loading" style="width:100%">
        <el-table-column prop="memberNo" label="编号" width="110" />
        <el-table-column label="会员" min-width="160">
          <template #default="{ row }">
            <div class="cell-entity">
              <el-avatar :size="36" icon="Avatar" />
              <div><strong>{{ row.name }}</strong><br><small>{{ row.phone||'无电话' }}</small></div>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="折扣" width="110">
          <template #default="{ row }">
            <el-tag :type="discountType(row.discount)" effect="dark" size="small" round>
              {{ row.discount ? (row.discount * 100).toFixed(0) + '%' : '100%' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="email" label="邮箱" width="170" show-overflow-tooltip />
        <el-table-column prop="address" label="地址" min-width="160" show-overflow-tooltip />
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="openEdit(row)">编辑</el-button>
            <el-popconfirm title="确定删除？" @confirm="handleDelete(row.id)">
              <template #reference><el-button link type="danger">删除</el-button></template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <el-dialog :title="dialogTitle" v-model="dialogVisible" width="560px" @close="resetForm" destroy-on-close>
      <el-form :model="form" :rules="rules" ref="formRef" label-position="top">
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="编号" prop="memberNo"><el-input v-model="form.memberNo" :disabled="isEdit" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="姓名" prop="name"><el-input v-model="form.name" /></el-form-item></el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="电话"><el-input v-model="form.phone" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="邮箱"><el-input v-model="form.email" /></el-form-item></el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="折扣率">
            <el-select v-model="form.discount" style="width:100%">
              <el-option label="100% (无折扣)" :value="1.00" />
              <el-option label="95%" :value="0.95" />
              <el-option label="90%" :value="0.90" />
              <el-option label="88%" :value="0.88" />
              <el-option label="85%" :value="0.85" />
              <el-option label="80%" :value="0.80" />
              <el-option label="75%" :value="0.75" />
              <el-option label="70%" :value="0.70" />
            </el-select>
          </el-form-item></el-col>
          <el-col :span="12"><el-form-item label="地址"><el-input v-model="form.address" /></el-form-item></el-col>
        </el-row>
        <el-form-item label="备注"><el-input v-model="form.remark" type="textarea" :rows="2" /></el-form-item>
      </el-form>
      <template #footer><el-button @click="dialogVisible=false">取消</el-button><el-button type="primary" :loading="submitting" @click="handleSubmit">保存</el-button></template>
    </el-dialog>

    <el-dialog title="批量导入" v-model="batchVisible" width="650px" destroy-on-close>
      <el-alert type="info" :closable="false" style="margin-bottom:16px">
        <template #title>格式：<code>编号|姓名|电话|地址|邮箱|折扣|备注</code>（编号+姓名必填，折扣如0.9=90%）</template>
      </el-alert>
      <el-input v-model="batchData" type="textarea" :rows="10" placeholder="每行一条记录..." />
      <template #footer><el-button @click="batchVisible=false">取消</el-button><el-button type="primary" :loading="batchLoading" @click="handleBatchImport">导入</el-button></template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { getMembers, createMember, updateMember, deleteMember, batchImportMembers } from '../../api'

const search = ref(''), tableData = ref([])
const loading = ref(false), submitting = ref(false)
const dialogVisible = ref(false), dialogTitle = ref('新增会员'), isEdit = ref(false), editId = ref(null), formRef = ref(null)

const form = reactive({ memberNo:'',name:'',phone:'',address:'',email:'',discount:1.00,remark:'' })
const rules = {
  memberNo: [{ required: true, message: '请输入编号' }],
  name: [{ required: true, message: '请输入姓名' }]
}
const batchVisible = ref(false), batchData = ref(''), batchLoading = ref(false)

const discountType = (d) => {
  if (!d || d >= 1) return 'success'
  if (d >= 0.9) return 'warning'
  return 'danger'
}

const loadData = async () => { loading.value = true; try { const r = await getMembers(search.value || undefined); tableData.value = r.data || [] } finally { loading.value = false } }

const resetForm = () => { Object.keys(form).forEach(k=>form[k]=k==='discount'?1.00:''); isEdit.value=false; editId.value=null; formRef.value?.resetFields() }
const openAdd = () => { resetForm(); dialogTitle.value='新增会员'; dialogVisible.value=true }
const openEdit = (row) => { resetForm(); dialogTitle.value='编辑会员'; isEdit.value=true; editId.value=row.id; Object.assign(form, row); dialogVisible.value=true }

const handleSubmit = async () => {
  if (!(await formRef.value.validate().catch(()=>false))) return
  submitting.value = true
  try {
    if (isEdit.value) { await updateMember(editId.value,{...form}); ElMessage.success('已更新') }
    else { await createMember({...form}); ElMessage.success('已新增') }
    dialogVisible.value = false; loadData()
  } finally { submitting.value = false }
}

const handleDelete = async (id) => { try { await deleteMember(id); ElMessage.success('已删除'); loadData() } catch {} }
const openBatchImport = () => { batchData.value=''; batchVisible.value=true }
const handleBatchImport = async () => {
  if (!batchData.value.trim()) { ElMessage.warning('请输入数据'); return }
  batchLoading.value = true
  try { const r = await batchImportMembers(batchData.value); ElMessage.success(`导入 ${r.data?.length||0} 条`); batchVisible.value=false; loadData() }
  finally { batchLoading.value = false }
}

onMounted(loadData)
</script>

<style scoped>
.admin-page { max-width: 1200px; margin: 0 auto; }
.page-top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px; flex-wrap: wrap; gap: 14px; }
.page-title { display: flex; align-items: center; gap: 14px; }
.title-icon { width: 44px; height: 44px; border-radius: 12px; background: color-mix(in srgb, var(--c) 10%, transparent); color: var(--c); display: flex; align-items: center; justify-content: center; }
.page-title h2 { font-size: 20px; margin: 0; color: var(--pms-text-primary); }
.page-title p { font-size: 13px; color: var(--pms-text-placeholder); margin: 2px 0 0; }
.page-actions { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.search-box { width: 210px; }
.mini-bar { font-size: 13px; color: var(--pms-text-muted); margin-bottom: 10px; display: flex; align-items: center; gap: 6px; }
.mini-dot { width: 8px; height: 8px; border-radius: 50%; }
.table-wrap { background: var(--pms-bg-card); border-radius: 14px; overflow: hidden; border: 1px solid var(--pms-border-light); }
.cell-entity { display: flex; align-items: center; gap: 10px; }
.cell-entity small { color: var(--pms-text-placeholder); }
</style>
