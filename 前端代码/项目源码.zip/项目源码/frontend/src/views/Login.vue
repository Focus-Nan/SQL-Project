<template>
  <div class="login-page">
    <!-- Video-like data stream canvas -->
    <canvas ref="videoCanvas" class="video-canvas"></canvas>
    <!-- Particle canvas -->
    <canvas ref="particleCanvas" class="particle-canvas"></canvas>

    <!-- Theme toggle -->
    <div class="login-theme-toggle"><ThemeToggle /></div>

    <!-- Animated background -->
    <div class="bg-animation">
      <div class="bg-shape shape-1"></div>
      <div class="bg-shape shape-2"></div>
      <div class="bg-shape shape-3"></div>
      <div class="bg-shape shape-4"></div>
      <div class="bg-dots"></div>
    </div>

    <!-- Floating data elements -->
    <div class="float-data data-1">¥12,800</div>
    <div class="float-data data-2">#PO2024</div>
    <div class="float-data data-3">98.5%</div>
    <div class="float-data data-4">32家</div>
    <div class="float-data data-5">KPI+</div>

    <!-- Login container -->
    <div class="login-wrapper">
      <!-- Left brand panel -->
      <div class="brand-panel">
        <div class="brand-content">
          <!-- Animated rings -->
          <div class="icon-container">
            <div class="icon-ring ring-1"></div>
            <div class="icon-ring ring-2"></div>
            <div class="icon-ring ring-3"></div>
            <div class="brand-icon">
              <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="8" y="20" width="48" height="36" rx="4" stroke="white" stroke-width="2.5" fill="none"/>
                <path d="M20 20V12C20 8.686 22.686 6 26 6H38C41.314 6 44 8.686 44 12V20" stroke="white" stroke-width="2.5" stroke-linecap="round"/>
                <circle cx="32" cy="40" r="4" fill="white"/>
                <path d="M32 36V40M32 44V44.01" stroke="white" stroke-width="2.5" stroke-linecap="round"/>
                <path d="M18 32H24M40 32H46" stroke="white" stroke-width="2" stroke-linecap="round" opacity="0.5"/>
              </svg>
            </div>
          </div>
          <h1 class="brand-title">采购管理系统</h1>
          <p class="brand-subtitle">
            <span class="typing-text">{{ typedText }}</span><span class="cursor">|</span>
          </p>
          <div class="brand-features">
            <div class="feature-item" v-for="(f,i) in features" :key="i" :style="{animationDelay: (0.3+i*0.15)+'s'}">
              <span class="feature-dot"></span>
              <span>{{ f }}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Right login form -->
      <div class="form-panel">
        <div class="form-card">
          <div class="form-header">
            <div class="login-avatar-wrap">
              <div class="login-avatar-ring" :class="{ loaded: previewAvatar }">
                <el-avatar :size="72" :src="previewAvatar" icon="UserFilled" />
              </div>
              <div class="login-avatar-shine" v-if="previewAvatar"></div>
            </div>
            <h2>{{ previewName || '欢迎回来' }}</h2>
            <p>请使用员工账号登录系统</p>
          </div>

          <el-form :model="form" :rules="rules" ref="formRef" label-width="0" size="large" class="login-form">
            <el-form-item prop="employeeNo">
              <div class="input-wrapper">
                <span class="input-icon">
                  <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M6 21v-2a4 4 0 014-4h4a4 4 0 014 4v2"/></svg>
                </span>
                <input
                  v-model="form.employeeNo"
                  type="text"
                  placeholder="员工编号"
                  class="modern-input"
                  autocomplete="off"
                  @input="onEmployeeNoChange"
                />
              </div>
            </el-form-item>
            <el-form-item prop="password">
              <div class="input-wrapper">
                <span class="input-icon">
                  <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/><circle cx="12" cy="16" r="1"/></svg>
                </span>
                <input
                  v-model="form.password"
                  :type="showPwd ? 'text' : 'password'"
                  placeholder="密码"
                  class="modern-input"
                  @keyup.enter="handleLogin"
                />
                <span class="input-suffix" @click="showPwd = !showPwd">
                  <svg v-if="!showPwd" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                  <svg v-else viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                </span>
              </div>
            </el-form-item>
            <el-form-item>
              <button
                type="button"
                class="login-btn"
                :class="{ loading: loading }"
                :disabled="loading"
                @click="handleLogin"
              >
                <span v-if="loading" class="btn-spinner"></span>
                <span>{{ loading ? '登录中...' : '登 录' }}</span>
              </button>
            </el-form-item>
          </el-form>

          <div class="form-footer">
            <div class="divider"><span>测试账户</span></div>
            <div class="test-accounts">
              <div class="account-tag admin">
                <span class="tag-dot"></span>
                <span>管理员：admin / 123456</span>
              </div>
              <div class="account-tag user">
                <span class="tag-dot"></span>
                <span>普通用户：user001 / 123456</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useUserStore } from '../store/user'
import { login } from '../api'
import request from '../utils/request'
import ThemeToggle from '../components/ThemeToggle.vue'

const router = useRouter()
const userStore = useUserStore()
const formRef = ref(null)
const loading = ref(false)
const showPwd = ref(false)
const previewAvatar = ref('')
const previewName = ref('')
let avatarTimer = null
const particleCanvas = ref(null)
const videoCanvas = ref(null)

const form = reactive({ employeeNo: '', password: '' })

const onEmployeeNoChange = () => {
  clearTimeout(avatarTimer)
  const no = form.employeeNo.trim()
  if (!no) {
    previewAvatar.value = ''
    previewName.value = ''
    return
  }
  avatarTimer = setTimeout(async () => {
    try {
      const res = await request.get('/auth/avatar/' + encodeURIComponent(no))
      previewAvatar.value = res.data || ''
      previewName.value = previewAvatar.value ? '欢迎回来' : ''
    } catch { previewAvatar.value = ''; previewName.value = '' }
  }, 400)
}
const rules = {
  employeeNo: [{ required: true, message: '请输入员工编号', trigger: 'blur' }],
  password: [{ required: true, message: '请输入密码', trigger: 'blur' }]
}

// ===== Typing Animation =====
const typedText = ref('')
const fullText = 'Purchase Management System'
const features = ['供应商 · 商品 · 采购一体化管理', '数据可视化 · 智能报表', '多角色权限 · 安全可靠']
let typeTimer = null, typeIdx = 0, deleting = false

const startTyping = () => {
  typeTimer = setInterval(() => {
    if (!deleting) {
      typedText.value = fullText.slice(0, typeIdx + 1)
      typeIdx++
      if (typeIdx >= fullText.length) { deleting = true; setTimeout(() => {}, 2000) }
    } else {
      typedText.value = fullText.slice(0, typeIdx - 1)
      typeIdx--
      if (typeIdx <= 0) { deleting = false }
    }
  }, 100)
}

// ===== Particle System =====
let animFrame = null
let particles = []
const COLORS = ['rgba(99,102,241,0.6)', 'rgba(139,92,246,0.5)', 'rgba(6,182,212,0.5)', 'rgba(236,72,153,0.4)', 'rgba(16,185,129,0.4)']
const initParticles = (w, h) => {
  particles = []
  const count = Math.floor((w * h) / 8000)
  for (let i = 0; i < count; i++) {
    particles.push({
      x: Math.random() * w, y: Math.random() * h,
      vx: (Math.random() - 0.5) * 0.3, vy: (Math.random() - 0.5) * 0.3,
      r: Math.random() * 1.5 + 0.5,
      color: COLORS[Math.floor(Math.random() * COLORS.length)]
    })
  }
}

const animateParticles = () => {
  const c = particleCanvas.value
  if (!c) return
  const ctx = c.getContext('2d')
  const w = c.width = window.innerWidth
  const h = c.height = window.innerHeight
  if (particles.length === 0) initParticles(w, h)

  ctx.clearRect(0, 0, w, h)

  particles.forEach((p, i) => {
    p.x += p.vx; p.y += p.vy
    if (p.x < 0 || p.x > w) p.vx *= -1
    if (p.y < 0 || p.y > h) p.vy *= -1

    ctx.beginPath()
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2)
    ctx.fillStyle = p.color
    ctx.fill()

    // Draw connections
    for (let j = i + 1; j < particles.length; j++) {
      const dx = p.x - particles[j].x
      const dy = p.y - particles[j].y
      const dist = Math.sqrt(dx * dx + dy * dy)
      if (dist < 120) {
        ctx.beginPath()
        ctx.moveTo(p.x, p.y)
        ctx.lineTo(particles[j].x, particles[j].y)
        ctx.strokeStyle = `rgba(99,102,241,${0.08 * (1 - dist / 120)})`
        ctx.lineWidth = 0.5
        ctx.stroke()
      }
    }
  })
  animFrame = requestAnimationFrame(animateParticles)
}

// ===== Data Stream "Video" Animation =====
let videoFrame = null
let streams = []
const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&*+-/=<>{}[]|💰📊📦🏭⚙️📈'
const STREAM_COLORS = [
  'rgba(99,102,241,0.7)', 'rgba(139,92,246,0.6)',
  'rgba(6,182,212,0.6)', 'rgba(16,185,129,0.5)', 'rgba(236,72,153,0.4)'
]

const initStreams = (w, h) => {
  streams = []
  const count = Math.floor(w / 60)
  for (let i = 0; i < count; i++) {
    streams.push({
      x: Math.random() * w,
      y: Math.random() * h * 0.5 - h,
      speed: Math.random() * 1.2 + 0.4,
      length: Math.floor(Math.random() * 12 + 4),
      chars: [],
      color: STREAM_COLORS[Math.floor(Math.random() * STREAM_COLORS.length)],
      fontSize: Math.floor(Math.random() * 10 + 11)
    })
  }
}

const animateStreams = () => {
  const c = videoCanvas.value
  if (!c) return
  const ctx = c.getContext('2d')
  const w = c.width = window.innerWidth
  const h = c.height = window.innerHeight
  if (streams.length === 0) initStreams(w, h)

  // Semi-transparent clear for trail effect
  ctx.fillStyle = 'rgba(15,15,26,0.15)'
  ctx.fillRect(0, 0, w, h)

  streams.forEach(s => {
    // Shift chars array
    if (s.chars.length === 0 || Math.random() < 0.08) {
      s.chars.unshift(CHARS[Math.floor(Math.random() * CHARS.length)])
      if (s.chars.length > s.length) s.chars.pop()
    }

    // Draw each char in the stream
    for (let i = 0; i < s.chars.length; i++) {
      const alpha = 1 - i / s.chars.length
      ctx.fillStyle = s.color.replace(/[\d.]+\)$/, alpha.toFixed(2) + ')')
      ctx.font = `bold ${s.fontSize}px "SF Mono","Consolas",monospace`
      ctx.fillText(s.chars[i], s.x, s.y - i * (s.fontSize + 2))
    }

    // Move down
    s.y += s.speed * (s.fontSize / 10)
    if (s.y > h + s.length * s.fontSize) {
      s.y = -s.length * s.fontSize
      s.x = Math.random() * w
      s.chars = []
    }
  })

  videoFrame = requestAnimationFrame(animateStreams)
}

// ===== Login =====
const handleLogin = async () => {
  const valid = await formRef.value.validate().catch(() => false)
  if (!valid) return
  loading.value = true
  try {
    const res = await login(form.employeeNo, form.password)
    const data = res.data
    userStore.setToken(data.token)
    userStore.setUserInfo({
      employeeId: data.employeeId, employeeNo: data.employeeNo,
      name: data.name, level: data.level, phone: data.phone, salary: data.salary,
      avatar: data.avatar
    })
    ElMessage.success('登录成功')
    router.push(data.level === 1 ? '/admin/dashboard' : '/user/myinfo')
  } catch (e) { /* handled by interceptor */ }
  finally { loading.value = false }
}

onMounted(() => { startTyping(); animateParticles(); animateStreams() })
onUnmounted(() => { clearInterval(typeTimer); cancelAnimationFrame(animFrame); cancelAnimationFrame(videoFrame) })
</script>

<style scoped>
.login-page {
  position: relative;
  width: 100%;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  background: var(--pms-login-bg);
}
.login-theme-toggle {
  position: fixed; top: 20px; right: 24px; z-index: 100;
}
.login-theme-toggle :deep(.theme-toggle) {
  color: rgba(255,255,255,0.5);
}
.login-theme-toggle :deep(.theme-toggle:hover) {
  color: rgba(255,255,255,0.9);
}

/* ===== Video Canvas (Data Stream) ===== */
.video-canvas {
  position: absolute; inset: 0; z-index: 0; pointer-events: none;
}
/* ===== Particle Canvas ===== */
.particle-canvas {
  position: absolute; inset: 0; z-index: 1; pointer-events: none;
}

/* ===== Animated Background ===== */
.bg-animation { position: absolute; inset: 0; overflow: hidden; }
.bg-shape {
  position: absolute; border-radius: 50%; filter: blur(80px); opacity: 0.4;
  animation: float 20s ease-in-out infinite;
}
.shape-1 {
  width: 500px; height: 500px;
  background: #6366f1;
  top: -15%; left: -10%;
  animation-delay: 0s;
}
.shape-2 {
  width: 400px; height: 400px;
  background: #8b5cf6;
  bottom: -20%; right: -5%;
  animation-delay: -7s;
}
.shape-3 {
  width: 300px; height: 300px;
  background: #06b6d4;
  top: 40%; right: 25%;
  animation-delay: -14s;
}
.shape-4 {
  width: 350px; height: 350px;
  background: #ec4899;
  bottom: 10%; left: 20%;
  animation-delay: -3s;
}
@keyframes float {
  0%, 100% { transform: translate(0, 0) scale(1); }
  25% { transform: translate(5%, -8%) scale(1.05); }
  50% { transform: translate(-3%, 5%) scale(0.95); }
  75% { transform: translate(-5%, -3%) scale(1.02); }
}
.bg-dots {
  position: absolute;
  inset: 0;
  background-image: radial-gradient(rgba(255,255,255,0.06) 1px, transparent 1px);
  background-size: 40px 40px;
}

/* ===== Login Wrapper ===== */
.login-wrapper {
  position: relative;
  z-index: 10;
  display: flex;
  width: 960px;
  min-height: 560px;
  background: rgba(255, 255, 255, 0.06);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 20px;
  overflow: hidden;
  box-shadow: 0 25px 60px rgba(0, 0, 0, 0.4);
}

/* ===== Left Brand Panel ===== */
.brand-panel {
  flex: 1;
  background: linear-gradient(135deg, rgba(99, 102, 241, 0.7) 0%, rgba(139, 92, 246, 0.7) 50%, rgba(6, 182, 212, 0.7) 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 50px 40px;
  position: relative;
  overflow: hidden;
}
.brand-panel::before {
  content: '';
  position: absolute;
  inset: 0;
  background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.06'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
}
.brand-content {
  position: relative;
  z-index: 1;
  color: #fff;
  text-align: center;
}
/* Icon rings animation */
.icon-container { position: relative; width: 100px; height: 100px; margin: 0 auto 24px; }
.icon-ring { position: absolute; inset: 0; border-radius: 50%; border: 2px solid rgba(255,255,255,0.2); animation: ringPulse 2.5s ease-out infinite; }
.ring-1 { animation-delay: 0s; }
.ring-2 { animation-delay: 0.6s; }
.ring-3 { animation-delay: 1.2s; }
@keyframes ringPulse {
  0% { transform: scale(0.85); opacity: 1; }
  100% { transform: scale(1.45); opacity: 0; }
}
.brand-icon {
  position: absolute; inset: 10px;
  background: rgba(255,255,255,0.15); border-radius: 20px;
  display: flex; align-items: center; justify-content: center;
  backdrop-filter: blur(10px); z-index: 1;
  animation: iconBeat 2.5s ease-in-out infinite;
}
@keyframes iconBeat {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.06); }
}
.brand-icon svg { width: 42px; height: 42px; }
.brand-title {
  font-size: 28px;
  font-weight: 700;
  margin-bottom: 6px;
  letter-spacing: 1px;
}
.brand-subtitle {
  font-size: 13px; opacity: 0.7; letter-spacing: 2px;
  text-transform: uppercase; margin-bottom: 35px; height: 20px;
}
.cursor { display: inline-block; animation: blink 1s step-end infinite; color: #fff; font-weight: 100; }
@keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
.brand-features {
  text-align: left;
  display: inline-flex;
  flex-direction: column;
  gap: 14px;
}
.feature-item {
  display: flex; align-items: center; gap: 10px; font-size: 14px; opacity: 0;
  animation: fadeSlideIn 0.6s ease forwards;
}
@keyframes fadeSlideIn {
  from { opacity: 0; transform: translateX(-20px); }
  to { opacity: 0.85; transform: translateX(0); }
}

/* ===== Floating Data ===== */
.float-data {
  position: absolute; z-index: 2; pointer-events: none;
  font-family: 'SF Mono','Consolas',monospace; font-weight: 700; font-size: 15px;
  color: rgba(255,255,255,0.12); animation: dataFloat 12s ease-in-out infinite;
}
.data-1 { top: 8%; left: 12%; animation-delay: 0s; font-size: 18px; }
.data-2 { top: 18%; right: 10%; animation-delay: -3s; font-size: 14px; }
.data-3 { bottom: 22%; left: 8%; animation-delay: -6s; font-size: 20px; }
.data-4 { bottom: 12%; right: 15%; animation-delay: -9s; font-size: 16px; }
.data-5 { top: 45%; left: 5%; animation-delay: -4s; font-size: 22px; }
@keyframes dataFloat {
  0%,100% { transform: translateY(0) rotate(0deg); opacity: 0.12; }
  25% { transform: translateY(-30px) rotate(2deg); opacity: 0.2; }
  50% { transform: translateY(-15px) rotate(-1deg); opacity: 0.08; }
  75% { transform: translateY(-40px) rotate(1deg); opacity: 0.18; }
}
.feature-dot {
  width: 6px;
  height: 6px;
  background: #fff;
  border-radius: 50%;
  flex-shrink: 0;
}

/* ===== Right Form Panel ===== */
.form-panel {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 50px 40px;
}
.form-card {
  width: 100%;
  max-width: 360px;
}
.form-header {
  margin-bottom: 28px; text-align: center;
}
.login-avatar-wrap {
  position: relative; display: inline-block; margin-bottom: 16px;
}
.login-avatar-ring {
  padding: 3px; border-radius: 50%;
  border: 2px solid rgba(255,255,255,0.12);
  transition: all 0.4s ease;
}
.login-avatar-ring.loaded {
  border-color: rgba(99,102,241,0.5);
  box-shadow: 0 0 20px rgba(99,102,241,0.2);
}
.login-avatar-shine {
  position: absolute; inset: -6px; border-radius: 50%;
  background: conic-gradient(from 0deg, transparent, rgba(99,102,241,0.3), transparent, rgba(139,92,246,0.3), transparent);
  animation: avatarSpin 3s linear infinite;
}
@keyframes avatarSpin { to { transform: rotate(360deg); } }
.form-header h2 {
  font-size: 26px;
  font-weight: 700;
  color: #fff;
  margin-bottom: 6px;
}
.form-header p {
  font-size: 14px;
  color: rgba(255,255,255,0.5);
}

/* ===== Modern Input ===== */
.login-form :deep(.el-form-item) {
  margin-bottom: 20px;
}
.login-form :deep(.el-form-item__error) {
  color: #f87171;
  padding-top: 4px;
}
.input-wrapper {
  display: flex;
  align-items: center;
  background: rgba(255,255,255,0.07);
  border: 1px solid rgba(255,255,255,0.12);
  border-radius: 12px;
  padding: 0 16px;
  transition: all 0.25s ease;
}
.input-wrapper:focus-within {
  border-color: rgba(99, 102, 241, 0.6);
  background: rgba(255,255,255,0.1);
  box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
}
.input-icon {
  display: flex;
  align-items: center;
  color: rgba(255,255,255,0.35);
  margin-right: 12px;
  flex-shrink: 0;
}
.input-suffix {
  display: flex;
  align-items: center;
  color: rgba(255,255,255,0.3);
  cursor: pointer;
  padding: 4px;
  margin-left: 8px;
  flex-shrink: 0;
  transition: color 0.2s;
}
.input-suffix:hover {
  color: rgba(255,255,255,0.6);
}
.modern-input {
  flex: 1;
  background: none;
  border: none;
  outline: none;
  height: 48px;
  font-size: 15px;
  color: #fff;
  font-family: inherit;
}
.modern-input::placeholder {
  color: rgba(255,255,255,0.3);
}
.modern-input:-webkit-autofill {
  -webkit-box-shadow: 0 0 0 30px rgba(30, 30, 60, 1) inset;
  -webkit-text-fill-color: #fff;
}

/* ===== Login Button ===== */
.login-btn {
  width: 100%;
  height: 48px;
  border: none;
  border-radius: 12px;
  background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
  color: #fff;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  letter-spacing: 1px;
}
.login-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(99, 102, 241, 0.4);
}
.login-btn:active {
  transform: translateY(0);
}
.login-btn:disabled {
  opacity: 0.7;
  cursor: not-allowed;
  transform: none;
}
.login-btn.loading {
  background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
}
.btn-spinner {
  width: 18px;
  height: 18px;
  border: 2px solid rgba(255,255,255,0.3);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
@keyframes spin {
  to { transform: rotate(360deg); }
}

/* ===== Footer ===== */
.form-footer {
  margin-top: 30px;
}
.divider {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 16px;
}
.divider::before,
.divider::after {
  content: '';
  flex: 1;
  height: 1px;
  background: rgba(255,255,255,0.1);
}
.divider span {
  font-size: 12px;
  color: rgba(255,255,255,0.3);
}
.test-accounts {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.account-tag {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: rgba(255,255,255,0.45);
  padding: 6px 12px;
  background: rgba(255,255,255,0.04);
  border-radius: 8px;
}
.tag-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  flex-shrink: 0;
}
.account-tag.admin .tag-dot { background: #6366f1; }
.account-tag.user .tag-dot { background: #06b6d4; }

/* ===== Responsive ===== */
@media (max-width: 768px) {
  .login-wrapper {
    flex-direction: column;
    width: 90%;
    min-height: auto;
  }
  .brand-panel {
    padding: 30px 20px;
  }
  .brand-title { font-size: 22px; }
  .brand-features { display: none; }
  .form-panel {
    padding: 30px 24px;
  }
}
</style>
