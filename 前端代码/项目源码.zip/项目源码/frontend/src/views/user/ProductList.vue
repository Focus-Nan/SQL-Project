<template>
  <div class="pl-page">
    <div class="pl-topbar">
      <h2><el-icon><Goods /></el-icon>商品浏览</h2>
      <div class="pl-search">
        <el-icon><Search /></el-icon>
        <input v-model="kw" placeholder="搜索商品名称..." @input="doFilter" />
        <button v-if="kw" @click="kw='';doFilter()">&times;</button>
      </div>
      <div class="pl-tabs">
        <span :class="{on:tab==='all'}" @click="tab='all'">全部</span>
        <span v-for="s in supList" :key="s.id" :class="{on:tab===s.id}" @click="tab=s.id">{{ s.name }}</span>
      </div>
    </div>

    <template v-if="!loading">
      <div class="pl-grid">
        <div class="pl-card" v-for="(p,i) in list" :key="p.id" :style="{'--h':(i*53+200)%360}">
          <div class="plc-top">
            <img v-if="p.image" :src="p.image" alt="" @error="$event.target.style.display='none'" />
            <el-icon v-if="!p.image" :size="36"><Goods /></el-icon>
          </div>
          <div class="plc-body">
            <h4 v-html="hl(p.name)"></h4>
            <p class="plc-desc" v-html="hl(p.description||'暂无简介')"></p>
            <div class="plc-meta">
              <span><el-icon :size="13"><OfficeBuilding /></el-icon>{{ p.supplier?.name||'—' }}</span>
              <span class="plc-price">¥{{ p.price }}</span>
            </div>
            <button class="plc-buy-btn" @click.stop="openBuy(p)">立即采购</button>
          </div>
        </div>
        <el-empty v-if="list.length===0" description="无匹配商品" />
      </div>
    </template>
    <div v-else class="pl-loading">
      <div v-for="n in 6" :key="n" class="pl-skel"><el-skeleton animated><template #template><div style="height:120px;background:#f3f4f6;border-radius:14px 14px 0 0"/><div style="padding:12px"><el-skeleton-item variant="text" style="width:60%;height:18px"/><el-skeleton-item variant="text" style="width:90%;height:13px;margin-top:6px"/></div></template></el-skeleton></div>
    </div>

    <!-- Purchase Dialog -->
    <el-dialog v-model="buyVisible" title="发起采购" width="460px" center>
      <div class="buy-product-info" v-if="buyProduct">
        <img v-if="buyProduct.image" :src="buyProduct.image" class="buy-img" />
        <el-icon v-else :size="40"><Goods /></el-icon>
        <div>
          <strong>{{ buyProduct.name }}</strong>
          <p>{{ buyProduct.supplier?.name||'—' }} · 单价 ¥{{ buyProduct.price }}</p>
        </div>
      </div>
      <el-form label-position="top" style="margin-top:16px">
        <el-form-item label="采购数量">
          <el-input-number v-model="buyQty" :min="1" :max="9999" style="width:100%" />
        </el-form-item>
        <el-form-item label="总价">
          <span class="buy-total">¥{{ (buyQty * (buyProduct?.price||0)).toLocaleString() }}</span>
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="buyRemark" placeholder="可选" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="buyVisible=false">取消</el-button>
        <el-button type="primary" :loading="buyLoading" @click="confirmBuy">确认采购</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'; import { getProducts, getSuppliers, createPurchaseMain, createPurchaseDetail } from '../../api'
import { useUserStore } from '../../store/user'
import { ElMessage } from 'element-plus'
const userStore = useUserStore()
const kw=ref(''),tab=ref('all'),all=ref([]),sups=ref([]),loading=ref(false)

// Purchase dialog
const buyVisible = ref(false), buyProduct = ref(null), buyQty = ref(1), buyRemark = ref(''), buyLoading = ref(false)

const openBuy = (product) => {
  buyProduct.value = product; buyQty.value = 1; buyRemark.value = ''; buyVisible.value = true
}

const confirmBuy = async () => {
  buyLoading.value = true
  try {
    const p = buyProduct.value; const qty = buyQty.value; const total = qty * p.price
    const no = 'PO' + Date.now()
    // Create purchase main
    const mRes = await createPurchaseMain({
      purchaseNo: no, employeeId: userStore.userInfo?.employeeId,
      totalQuantity: qty, totalPrice: total, purchaseTime: new Date().toISOString().slice(0,19).replace('T',' '),
      remark: buyRemark.value || '快速采购'
    })
    // Create purchase detail
    await createPurchaseDetail({
      detailNo: 'D' + Date.now().toString(36).toUpperCase(),
      purchaseMainId: mRes.data.id, productId: p.id,
      quantity: qty, unitPrice: p.price, totalPrice: total
    })
    ElMessage.success(`已发起采购: ${no}`)
    buyVisible.value = false
  } catch {} finally { buyLoading.value = false }
}
const supList=computed(()=>{const m={};all.value.forEach(p=>{if(p.supplier){const s=p.supplier;if(!m[s.id])m[s.id]={id:s.id,name:s.name};m[s.id].count=(m[s.id].count||0)+1}});return Object.values(m).sort((a,b)=>b.count-a.count)})
const list=computed(()=>{let r=all.value;if(kw.value){const k=kw.value.toLowerCase();r=r.filter(p=>p.name.toLowerCase().includes(k)||(p.description||'').toLowerCase().includes(k))}if(tab.value!=='all')r=r.filter(p=>p.supplier&&p.supplier.id===tab.value);return r})
const hl=t=>{if(!kw.value||!t)return t||'';const e=kw.value.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');return t.replace(new RegExp(`(${e})`,'gi'),'<em style="background:#fef08a;color:#854d0e;font-weight:600;padding:1px 3px;border-radius:3px;font-style:normal">$1</em>')}
const doFilter=()=>{}
onMounted(async()=>{loading.value=true;try{const[pr]=await Promise.all([getProducts(),getSuppliers()]);all.value=pr.data||[]}finally{loading.value=false}})
</script>

<style scoped>
.pl-page { max-width:1100px; margin:0 auto; }
.pl-topbar { margin-bottom:20px; }
.pl-topbar h2 { display:flex;align-items:center;gap:8px;font-size:20px;color:var(--pms-text-primary);margin:0 0 14px; }
.pl-search {
  position:relative;display:flex;align-items:center;background: var(--pms-bg-card);border:1px solid var(--pms-border-color);
  border-radius:10px;padding:0 12px;margin-bottom:14px;max-width:360px;
}
.pl-search:focus-within { border-color:var(--pms-accent-primary);box-shadow:0 0 0 3px rgba(99,102,241,.08); }
.pl-search .el-icon { color:var(--pms-text-placeholder);margin-right:6px; }
.pl-search input { flex:1;border:none;outline:none;height:40px;font-size:14px;color:var(--pms-text-secondary);background:transparent; }
.pl-search input::placeholder { color:var(--pms-text-disabled); }
.pl-search button { background:none;border:none;color:var(--pms-text-placeholder);font-size:18px;cursor:pointer; }
.pl-tabs { display:flex;gap:4px;flex-wrap:wrap; }
.pl-tabs span {
  padding:5px 14px;border-radius:20px;font-size:13px;cursor:pointer;color:var(--pms-text-muted);
  background: var(--pms-bg-card);border:1px solid var(--pms-border-color);transition:all 0.15s;white-space:nowrap;
}
.pl-tabs span:hover { border-color:var(--pms-text-disabled); }
.pl-tabs span.on { background:var(--pms-accent-primary);color:#fff;border-color:var(--pms-accent-primary); }

.pl-grid { display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px; }
.pl-card {
  background: var(--pms-bg-card);border-radius:14px;overflow:hidden;border:1px solid var(--pms-border-color);
  transition:all 0.3s cubic-bezier(.4,0,.2,1);cursor:default;
  animation: cardPop 0.45s ease both;
}
.pl-card:nth-child(1) { animation-delay: 0.03s; }
.pl-card:nth-child(2) { animation-delay: 0.06s; }
.pl-card:nth-child(3) { animation-delay: 0.09s; }
.pl-card:nth-child(4) { animation-delay: 0.12s; }
.pl-card:nth-child(5) { animation-delay: 0.15s; }
.pl-card:nth-child(6) { animation-delay: 0.18s; }
.pl-card:nth-child(n+7) { animation-delay: 0.2s; }
@keyframes cardPop {
  from { opacity:0; transform: translateY(20px) scale(0.96); }
  to { opacity:1; transform: translateY(0) scale(1); }
}
.pl-card:hover { transform:translateY(-6px) scale(1.01);box-shadow:0 12px 30px rgba(99,102,241,.1); }
.plc-top {
  transition: filter 0.3s;
}
.pl-card:hover .plc-top { filter: brightness(1.1); }
.plc-top {
  height:140px;background:linear-gradient(135deg,hsl(var(--h),55%,55%),hsl(calc(var(--h)+35),50%,42%));
  display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,.7);
  overflow:hidden;
}
.plc-top img { width:100%;height:100%;object-fit:cover;transition:transform 0.4s; }
.pl-card:hover .plc-top img { transform:scale(1.08); }
.plc-body { padding:14px 16px; }
.plc-body h4 { font-size:15px;font-weight:600;color:var(--pms-text-primary);margin:0 0 4px; }
.plc-desc { font-size:12px;color:var(--pms-text-placeholder);margin:0 0 10px;line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden; }
.plc-meta { display:flex;justify-content:space-between;align-items:center;font-size:12px;color:var(--pms-text-muted); }
.plc-meta span { display:flex;align-items:center;gap:3px; }
.plc-price { font-weight:700!important;font-size:16px!important;color:var(--pms-accent-primary)!important; }
.plc-buy-btn {
  width:100%; margin-top:10px; padding:7px 0; border:none; border-radius:8px;
  background:linear-gradient(135deg,#6366f1,#8b5cf6); color:#fff;
  font-size:13px; font-weight:600; cursor:pointer; transition:all 0.25s;
  opacity:0; transform:translateY(4px);
}
.pl-card:hover .plc-buy-btn { opacity:1; transform:translateY(0); }
.plc-buy-btn:hover { box-shadow:0 4px 15px rgba(99,102,241,.4); transform:scale(1.02); }
.plc-buy-btn:active { transform:scale(0.98); }

/* Buy Dialog */
.buy-product-info { display:flex; align-items:center; gap:14px; background:var(--pms-table-header-bg); padding:14px; border-radius:12px; }
.buy-img { width:64px;height:64px;border-radius:10px;object-fit:cover; }
.buy-product-info strong { font-size:15px; color:var(--pms-text-primary); }
.buy-product-info p { font-size:12px; color:var(--pms-text-placeholder); margin-top:2px; }
.buy-total { font-size:22px;font-weight:700;color:var(--pms-accent-primary); }
.pl-loading,.pl-skel { border-radius:14px;overflow:hidden; } .pl-loading { display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px; }
@media (max-width:500px){ .pl-grid{grid-template-columns:1fr 1fr} .pl-tabs{overflow-x:auto;flex-wrap:nowrap;padding-bottom:4px} }
</style>
