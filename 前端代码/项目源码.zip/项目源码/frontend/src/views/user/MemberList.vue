<template>
  <div class="member-page">
    <div class="page-header">
      <div class="page-title">
        <h2><el-icon :size="22"><Avatar /></el-icon> 会员信息</h2>
        <p>查看会员名录与折扣权益</p>
      </div>
      <div class="search-bar">
        <div class="modern-search">
          <el-icon class="search-icon"><Search /></el-icon>
          <input v-model="search" placeholder="搜索会员姓名或编号..." @keyup.enter="loadData" />
          <button v-if="search" class="clear-btn" @click="search='';loadData()">×</button>
        </div>
      </div>
    </div>

    <!-- Discount Tier Legend -->
    <div class="tier-legend">
      <span class="tier-label">折扣等级：</span>
      <span class="tier-tag vip"><span class="tier-dot"></span>VIP (70%~85%)</span>
      <span class="tier-tag gold"><span class="tier-dot"></span>金牌 (88%~90%)</span>
      <span class="tier-tag silver"><span class="tier-dot"></span>银牌 (95%)</span>
      <span class="tier-tag normal"><span class="tier-dot"></span>普通 (100%)</span>
    </div>

    <!-- Loading -->
    <div v-if="loading" class="loading-grid">
      <div v-for="n in 4" :key="n" class="skeleton-card"><el-skeleton animated :rows="3" /></div>
    </div>

    <!-- Member Grid -->
    <div class="member-grid" v-if="!loading">
      <div class="member-card" v-for="m in tableData" :key="m.id" :class="discountClass(m.discount)">
        <!-- Top gradient bar -->
        <div class="mc-top"></div>
        <div class="mc-body">
          <div class="mc-avatar">
            <el-avatar :size="52" icon="Avatar" />
            <div class="mc-discount-badge">{{ discountLabel(m.discount) }}</div>
          </div>
          <h4 class="mc-name">{{ m.name }}</h4>
          <p class="mc-no">{{ m.memberNo }}</p>

          <div class="mc-details">
            <div class="mc-row" v-if="m.phone">
              <el-icon :size="14"><Phone /></el-icon>
              <span>{{ m.phone }}</span>
            </div>
            <div class="mc-row" v-if="m.email">
              <el-icon :size="14"><Message /></el-icon>
              <span>{{ m.email }}</span>
            </div>
            <div class="mc-row" v-if="m.address">
              <el-icon :size="14"><Location /></el-icon>
              <span>{{ m.address }}</span>
            </div>
          </div>

          <!-- Discount bar -->
          <div class="mc-discount-bar">
            <div class="discount-fill" :style="{ width: (m.discount||1) * 100 + '%' }"></div>
            <span class="discount-text">{{ discountLabel(m.discount) }}</span>
          </div>

          <div class="mc-remark" v-if="m.remark">
            <el-icon :size="12"><InfoFilled /></el-icon>
            {{ m.remark }}
          </div>
        </div>
      </div>

      <el-empty v-if="tableData.length===0" description="未找到会员" />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { getMembers } from '../../api'

const search = ref('')
const tableData = ref([])
const loading = ref(false)

const loadData = async () => {
  loading.value = true
  try { const r = await getMembers(search.value||undefined); tableData.value = r.data||[] }
  finally { loading.value = false }
}

const discountLabel = (d) => {
  if (!d || d >= 1) return '100%'
  return (d * 100).toFixed(0) + '%'
}

const discountClass = (d) => {
  if (!d || d >= 1) return 'tier-normal'
  if (d >= 0.9) return 'tier-silver'
  if (d >= 0.8) return 'tier-gold'
  return 'tier-vip'
}

onMounted(loadData)
</script>

<style scoped>
.member-page { max-width: 1000px; margin: 0 auto; }

.page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 20px; flex-wrap: wrap; gap: 14px; }
.page-title h2 { display: flex; align-items: center; gap: 8px; font-size: 22px; color: var(--pms-text-primary); margin: 0; }
.page-title p { font-size: 13px; color: var(--pms-text-placeholder); margin: 4px 0 0; }
.modern-search { position: relative; display: flex; align-items: center; background: var(--pms-bg-card); border: 1px solid var(--pms-border-color); border-radius: 12px; padding: 0 14px; width: 280px; transition: all 0.2s; }
.modern-search:focus-within { border-color: #ec4899; box-shadow: 0 0 0 3px rgba(236,72,153,0.1); }
.modern-search .search-icon { color: var(--pms-text-placeholder); margin-right: 8px; flex-shrink: 0; }
.modern-search input { flex: 1; border: none; outline: none; height: 40px; font-size: 14px; color: var(--pms-text-secondary); background: transparent; font-family: inherit; }
.modern-search input::placeholder { color: var(--pms-text-disabled); }
.clear-btn { background: none; border: none; color: var(--pms-text-placeholder); font-size: 18px; cursor: pointer; padding: 0 4px; }

/* Tier Legend */
.tier-legend { display: flex; align-items: center; gap: 12px; margin-bottom: 18px; flex-wrap: wrap; }
.tier-label { font-size: 13px; color: var(--pms-text-muted); font-weight: 500; }
.tier-tag { display: flex; align-items: center; gap: 5px; font-size: 12px; color: var(--pms-text-muted); padding: 4px 10px; background: var(--pms-table-header-bg); border-radius: 20px; }
.tier-dot { width: 8px; height: 8px; border-radius: 50%; }
.tier-tag.vip .tier-dot { background: #ef4444; }
.tier-tag.gold .tier-dot { background: #f59e0b; }
.tier-tag.silver .tier-dot { background: #6366f1; }
.tier-tag.normal .tier-dot { background: #10b981; }

/* Member Grid */
.member-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 18px; }
.member-card { background: var(--pms-bg-card); border-radius: 16px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.04); border: 1px solid var(--pms-border-light); transition: all 0.3s; }
.member-card:hover { transform: translateY(-4px); box-shadow: 0 10px 28px rgba(0,0,0,0.08); }

.mc-top { height: 6px; }
.tier-vip .mc-top { background: linear-gradient(90deg, #ef4444, #f97316); }
.tier-gold .mc-top { background: linear-gradient(90deg, #f59e0b, #eab308); }
.tier-silver .mc-top { background: linear-gradient(90deg, #6366f1, #8b5cf6); }
.tier-normal .mc-top { background: linear-gradient(90deg, #10b981, #34d399); }

.mc-body { padding: 16px 18px 18px; text-align: center; }
.mc-avatar { position: relative; display: inline-block; margin-top: -38px; }
.mc-discount-badge {
  position: absolute; bottom: -4px; right: -8px;
  font-size: 10px; font-weight: 700; color: #fff;
  padding: 2px 7px; border-radius: 10px;
  white-space: nowrap;
}
.tier-vip .mc-discount-badge { background: #ef4444; }
.tier-gold .mc-discount-badge { background: #f59e0b; }
.tier-silver .mc-discount-badge { background: #6366f1; }
.tier-normal .mc-discount-badge { background: #10b981; }

.mc-name { font-size: 16px; font-weight: 600; color: var(--pms-text-primary); margin: 12px 0 2px; }
.mc-no { font-size: 12px; color: var(--pms-text-placeholder); margin: 0 0 14px; font-family: 'SF Mono', 'Consolas', monospace; }

.mc-details { display: flex; flex-direction: column; gap: 6px; margin-bottom: 14px; text-align: left; }
.mc-row { display: flex; align-items: center; gap: 6px; font-size: 12px; color: var(--pms-text-muted); }
.mc-row .el-icon { color: var(--pms-text-disabled); flex-shrink: 0; }

/* Discount Bar */
.mc-discount-bar {
  position: relative; height: 22px; background: var(--pms-bg-hover);
  border-radius: 11px; overflow: hidden; margin-bottom: 10px;
}
.discount-fill {
  height: 100%; border-radius: 11px;
  transition: width 0.5s ease;
}
.tier-vip .discount-fill { background: linear-gradient(90deg, #ef4444, #f97316); }
.tier-gold .discount-fill { background: linear-gradient(90deg, #f59e0b, #eab308); }
.tier-silver .discount-fill { background: linear-gradient(90deg, #6366f1, #8b5cf6); }
.tier-normal .discount-fill { background: linear-gradient(90deg, #10b981, #34d399); }
.discount-text { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 700; color: #fff; mix-blend-mode: difference; }

.mc-remark { display: flex; align-items: center; gap: 4px; font-size: 11px; color: var(--pms-text-placeholder); justify-content: center; }

.loading-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 18px; }
.skeleton-card { background: var(--pms-bg-card); border-radius: 16px; padding: 20px; }

@media (max-width: 600px) { .member-grid { grid-template-columns: repeat(2, 1fr); } }
</style>
