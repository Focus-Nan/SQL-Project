<template>
  <div class="user-shell">
    <aside class="us-sidebar">
      <div class="us-brand">
        <div class="us-logo"><el-icon :size="22"><Goods /></el-icon></div>
        <span class="us-title">采购系统</span>
      </div>
      <nav class="us-nav">
        <router-link to="/user/myinfo" class="us-item" active-class="active">
          <el-icon><User /></el-icon><span>个人信息</span>
        </router-link>
        <router-link to="/user/products" class="us-item" active-class="active">
          <el-icon><Goods /></el-icon><span>商品浏览</span>
        </router-link>
        <router-link to="/user/purchases" class="us-item" active-class="active">
          <el-icon><ShoppingCart /></el-icon><span>采购记录</span>
        </router-link>
      </nav>
    </aside>

    <div class="us-main">
      <header class="us-topbar">
        <el-breadcrumb separator="·">
          <el-breadcrumb-item>用户中心</el-breadcrumb-item>
          <el-breadcrumb-item>{{ pageTitle }}</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="us-tb-right">
          <span class="us-clock">{{ nowTime }}</span>
          <ThemeToggle />
          <el-avatar :size="28" icon="User" />
          <span class="us-uname">{{ userStore.userInfo?.name }}</span>
          <el-button text circle @click="handleLogout"><el-icon :size="16"><SwitchButton /></el-icon></el-button>
        </div>
      </header>
      <main class="us-content"><router-view /></main>
    </div>
  </div>
</template>

<script setup>
import { computed, ref, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '../../store/user'
import { ElMessageBox } from 'element-plus'
import ThemeToggle from '../../components/ThemeToggle.vue'

const route = useRoute(); const router = useRouter(); const userStore = useUserStore()
const nowTime = ref('')
const pageTitle = computed(() => ({myinfo:'个人信息',products:'商品浏览',purchases:'采购记录'}[route.path.split('/').pop()]||''))

let t
onMounted(()=>{const u=()=>{const d=new Date();nowTime.value=d.toLocaleTimeString('zh-CN',{hour12:false})};u();t=setInterval(u,1e3)})
onUnmounted(()=>clearInterval(t))
const handleLogout=async()=>{try{await ElMessageBox.confirm('确定退出？','',{type:'warning',confirmButtonText:'退出'});userStore.logout();router.push('/login')}catch{}}
</script>

<style scoped>
.user-shell { display:flex; height:100vh; background:var(--pms-bg-page); }
.us-sidebar { width:200px; flex-shrink:0; background:var(--pms-user-sidebar-bg); border-right:1px solid var(--pms-border-color); display:flex; flex-direction:column; }
.us-brand { display:flex; align-items:center; gap:10px; padding:0 18px; height:56px; border-bottom:1px solid var(--pms-user-sidebar-border); }
.us-logo { width:34px;height:34px;border-radius:10px;background:linear-gradient(135deg,#10b981,#059669);display:flex;align-items:center;justify-content:center;color:#fff; }
.us-title { font-size:16px;font-weight:600;color:var(--pms-text-primary); }
.us-nav { flex:1; padding:12px 8px; display:flex; flex-direction:column; gap:2px; }
.us-item {
  display:flex;align-items:center;gap:10px;padding:0 14px;height:42px;
  border-radius:10px;color:var(--pms-user-sidebar-text);text-decoration:none;font-size:14px;transition:all 0.15s;
}
.us-item:hover { background:var(--pms-user-sidebar-hover-bg);color:var(--pms-user-sidebar-hover-text); }
.us-item.active { background:var(--pms-user-sidebar-active-bg);color:var(--pms-user-sidebar-active-text);font-weight:500; }
.us-item .el-icon { font-size:18px;flex-shrink:0; }
.us-main { flex:1;display:flex;flex-direction:column;min-width:0; }
.us-topbar { height:56px;background:var(--pms-bg-card);border-bottom:1px solid var(--pms-border-color);display:flex;align-items:center;justify-content:space-between;padding:0 24px;flex-shrink:0; }
.us-tb-right { display:flex;align-items:center;gap:12px; }
.us-clock { font-size:13px;color:var(--pms-text-placeholder);font-variant-numeric:tabular-nums; }
.us-uname { font-size:14px;color:var(--pms-text-secondary); }
.us-content { flex:1;overflow-y:auto;padding:24px; }
</style>
