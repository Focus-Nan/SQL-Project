<template>
  <div class="mi-page" v-if="info">
    <!-- Hero -->
    <div class="mi-hero">
      <label class="mi-avatar" title="点击更换头像">
        <input type="file" accept="image/*" hidden @change="onAvatarChange" />
        <el-avatar :size="64" :src="info.avatar" icon="UserFilled" />
        <div class="mi-avatar-hover"><el-icon :size="20"><Camera /></el-icon></div>
        <div class="mi-level" :class="info.level===1?'admin':'user'">{{ info.level===1?'管理':'用户' }}</div>
      </label>
      <div class="mi-hinfo">
        <h2>{{ info.name }}</h2>
        <p>{{ info.employeeNo }} · {{ info.phone||'未填电话' }}</p>
      </div>
    </div>

    <!-- Info Cards -->
    <div class="mi-grid">
      <div class="mi-card">
        <div class="mic-hd"><el-icon><User /></el-icon>基本资料</div>
        <div class="mic-row"><span>员工编号</span><strong>{{ info.employeeNo }}</strong></div>
        <div class="mic-row"><span>姓名</span><strong>{{ info.name }}</strong></div>
        <div class="mic-row"><span>角色</span><el-tag size="small" effect="dark" round :type="info.level===1?'danger':'success'">{{ info.level===1?'管理员':'普通用户' }}</el-tag></div>
      </div>
      <div class="mi-card">
        <div class="mic-hd"><el-icon><Connection /></el-icon>联系与薪酬</div>
        <div class="mic-row"><span>电话</span><strong>{{ info.phone||'—' }}</strong></div>
        <div class="mic-row"><span>薪资</span><strong class="mi-salary">¥{{ (info.salary||0).toLocaleString() }}</strong></div>
        <div class="mic-row"><span>备注</span><strong>{{ info.remark||'—' }}</strong></div>
      </div>
    </div>
  </div>
  <div v-else-if="loading" class="mi-loading"><el-skeleton :rows="5" animated /></div>
</template>

<script setup>
import { ref, onMounted } from 'vue'; import { getCurrentUser, uploadAvatar } from '../../api'
import { useUserStore } from '../../store/user'
import { ElMessage } from 'element-plus'
const userStore=useUserStore()
const info=ref(null),loading=ref(false)
onMounted(async()=>{loading.value=true;try{const r=await getCurrentUser();info.value=r.data}catch{};loading.value=false})

const onAvatarChange = async (e) => {
  const file = e.target.files[0]
  if (!file) return
  if (file.size > 2*1024*1024) { ElMessage.warning('图片不能超过2MB'); return }
  const reader = new FileReader()
  reader.onload = async () => {
    try { await uploadAvatar(reader.result); userStore.setAvatar(reader.result); info.value.avatar = reader.result; ElMessage.success('头像已更新') } catch {}
  }
  reader.readAsDataURL(file)
  e.target.value = ''
}
</script>

<style scoped>
.mi-page { max-width:680px; margin:0 auto; }
.mi-hero {
  display:flex; align-items:center; gap:20px; background: var(--pms-bg-card); border-radius:16px;
  padding:28px 32px; margin-bottom:20px; border:1px solid var(--pms-border-color);
  animation: heroIn 0.5s ease both;
}
@keyframes heroIn { from{opacity:0;transform:translateY(-10px)} to{opacity:1;transform:translateY(0)} }

.mi-card {
  animation: cardIn 0.4s ease both;
}
.mi-card:nth-child(1) { animation-delay: 0.15s; }
.mi-card:nth-child(2) { animation-delay: 0.25s; }
@keyframes cardIn { from{opacity:0;transform:translateY(14px)} to{opacity:1;transform:translateY(0)} }
.mi-avatar { position:relative; cursor:pointer; display:inline-block; }
.mi-avatar-hover {
  position:absolute; inset:0; border-radius:50%; background:rgba(0,0,0,0.4);
  display:flex; align-items:center; justify-content:center; color:#fff;
  opacity:0; transition:opacity 0.2s;
}
.mi-avatar:hover .mi-avatar-hover { opacity:1; }
.mi-level {
  position:absolute; bottom:-4px; right:-4px; font-size:10px; font-weight:600; color:#fff;
  padding:1px 8px; border-radius:10px;
}
.mi-level.admin { background:var(--pms-accent-red); }
.mi-level.user { background:#10b981; }
.mi-hinfo h2 { font-size:22px; color:var(--pms-text-primary); margin:0; }
.mi-hinfo p { font-size:13px; color:var(--pms-text-placeholder); margin:4px 0 0; }
.mi-grid { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
.mi-card { background: var(--pms-bg-card); border-radius:14px; border:1px solid var(--pms-border-color); overflow:hidden; }
.mic-hd { display:flex;align-items:center;gap:6px;padding:14px 18px;font-size:13px;font-weight:600;color:var(--pms-text-tertiary);border-bottom:1px solid var(--pms-card-divider); }
.mic-hd .el-icon { color:var(--pms-accent-primary); }
.mic-row { display:flex; justify-content:space-between; align-items:center; padding:10px 18px; font-size:13px;color:var(--pms-text-muted); }
.mic-row:not(:last-child) { border-bottom:1px solid var(--pms-border-subtle); }
.mic-row strong { color:var(--pms-text-primary);font-weight:500; }
.mi-salary { color:var(--pms-accent-green)!important;font-weight:600!important; }
.mi-loading { background: var(--pms-bg-card);border-radius:14px;padding:24px; }
@media (max-width:600px){ .mi-grid{grid-template-columns:1fr} }
</style>
