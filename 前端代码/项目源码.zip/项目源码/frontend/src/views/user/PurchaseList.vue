<template>
  <div class="pu-page">
    <div class="pu-head">
      <h2><el-icon><ShoppingCart /></el-icon>采购记录</h2>
      <div class="pu-summary">
        <span><strong>{{ mainData.length }}</strong> 笔采购单</span>
        <span class="pu-total">总额 <strong>¥{{ total.toLocaleString() }}</strong></span>
      </div>
    </div>

    <div v-if="loading" class="pu-loading"><div v-for="n in 3" :key="n" class="pu-skel"><el-skeleton animated :rows="2"/></div></div>

    <div class="pu-list" v-else>
      <div class="pu-card" v-for="po in mainData" :key="po.id" :class="{open:openId===po.id}">
        <div class="pu-row" @click="openId=openId===po.id?null:po.id;if(openId!==po.id)loadDetail(po.id)">
          <div class="pu-icon" :style="{background:grads[po.id%6]}"><el-icon :size="18"><Document /></el-icon></div>
          <div class="pu-info">
            <span class="pu-no">{{ po.purchaseNo }}</span>
            <span class="pu-sub">{{ po.employee?.name||'—' }} · {{ po.purchaseTime||'—' }}</span>
          </div>
          <div class="pu-stats">
            <span>{{ po.totalQuantity||0 }} 件</span>
            <span class="pu-amount">¥{{ (po.totalPrice||0).toLocaleString() }}</span>
          </div>
          <el-icon class="pu-arr" :class="{rot:openId===po.id}"><ArrowDown /></el-icon>
          <el-popconfirm title="确定删除该采购记录？明细也将一并删除。" @confirm="handleDelete(po.id)" @click.stop>
            <template #reference>
              <el-button type="danger" size="small" plain @click.stop class="pu-del-btn">
                <el-icon :size="14"><Delete /></el-icon> 删除
              </el-button>
            </template>
          </el-popconfirm>
        </div>
        <div class="pu-detail" v-if="openId===po.id">
          <div class="pud-item" v-for="d in details" :key="d.id">
            <span class="pud-name">{{ d.product?.name||'—' }}</span>
            <span class="pud-qty">×{{ d.quantity }}</span>
            <span class="pud-price">¥{{ (d.unitPrice||0).toLocaleString() }}</span>
            <span class="pud-sub">¥{{ (d.totalPrice||0).toLocaleString() }}</span>
          </div>
          <el-empty v-if="details.length===0" description="暂无明细" :image-size="50"/>
        </div>
      </div>
      <el-empty v-if="mainData.length===0" description="暂无采购记录"/>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
const mainData=ref([]),loading=ref(false),openId=ref(null),details=ref([])
const grads=['linear-gradient(135deg,#6366f1,#8b5cf6)','linear-gradient(135deg,#10b981,#059669)','linear-gradient(135deg,#f59e0b,#d97706)','linear-gradient(135deg,#ef4444,#dc2626)','linear-gradient(135deg,#06b6d4,#0891b2)','linear-gradient(135deg,#ec4899,#db2777)']
const total=computed(()=>mainData.value.reduce((s,p)=>s+(p.totalPrice||0),0))
const loadDetail=async(id)=>{try{const r=await getPurchaseDetails(id);details.value=r.data||[]}catch{}}
import { ElMessage } from 'element-plus'
import { getPurchaseMains, getPurchaseDetails, deletePurchaseMain } from '../../api'
const handleDelete = async (id) => { try{await deletePurchaseMain(id);ElMessage.success('已删除');openId.value=null;details.value=[];loadMain()}catch{} }
const loadMain = async()=>{loading.value=true;try{const r=await getPurchaseMains();mainData.value=r.data||[]}finally{loading.value=false}}
onMounted(loadMain)
</script>

<style scoped>
.pu-page { max-width:800px; margin:0 auto; }
.pu-head { display:flex; justify-content:space-between; align-items:flex-end; margin-bottom:18px; }
.pu-head h2 { display:flex;align-items:center;gap:8px;font-size:20px;color:var(--pms-text-primary);margin:0; }
.pu-summary { display:flex;gap:16px;font-size:13px;color:var(--pms-text-muted); }
.pu-summary strong { color:var(--pms-text-primary); }
.pu-total strong { color:var(--pms-accent-primary); }
.pu-list { display:flex;flex-direction:column;gap:10px; }
.pu-card {
  background: var(--pms-bg-card);border-radius:14px;border:1px solid var(--pms-border-color);overflow:hidden;
  transition:all 0.25s ease;
  animation: fadeUp 0.35s ease both;
}
.pu-card:nth-child(1) { animation-delay: 0.02s; }
.pu-card:nth-child(2) { animation-delay: 0.04s; }
.pu-card:nth-child(3) { animation-delay: 0.06s; }
.pu-card:nth-child(4) { animation-delay: 0.08s; }
.pu-card:nth-child(5) { animation-delay: 0.10s; }
.pu-card:nth-child(6) { animation-delay: 0.12s; }
.pu-card:nth-child(n+7) { animation-delay: 0.14s; }
@keyframes fadeUp { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
.pu-card:hover { border-color:#c7d2fe; transform: translateX(4px); }
.pu-card.open { border-color:#c7d2fe;box-shadow:0 0 0 3px rgba(99,102,241,.06); }
.pu-row { display:flex;align-items:center;gap:14px;padding:14px 18px;cursor:pointer; }
.pu-icon { width:40px;height:40px;border-radius:11px;display:flex;align-items:center;justify-content:center;color:#fff;flex-shrink:0; }
.pu-info { flex:1;min-width:0;display:flex;flex-direction:column; }
.pu-no { font-weight:600;font-size:14px;color:var(--pms-text-primary); }
.pu-sub { font-size:12px;color:var(--pms-text-placeholder);margin-top:1px; }
.pu-stats { display:flex;flex-direction:column;align-items:flex-end;gap:2px;font-size:12px;color:var(--pms-text-muted);flex-shrink:0; }
.pu-amount { font-weight:700;font-size:15px;color:var(--pms-accent-primary); }
.pu-arr { color:var(--pms-text-placeholder);transition:transform 0.25s;flex-shrink:0; }
.pu-arr.rot { transform:rotate(180deg);color:var(--pms-accent-primary); }
.pu-del-btn { flex-shrink:0; }
.pu-detail { border-top:1px solid #f1f5f9;padding:6px 0; }
.pud-item { display:flex;align-items:center;gap:12px;padding:10px 18px;font-size:13px; }
.pud-item:not(:last-child) { border-bottom:1px solid var(--pms-border-subtle); }
.pud-name { flex:1;color:var(--pms-text-secondary); }
.pud-qty { color:var(--pms-text-placeholder); }
.pud-price { color:var(--pms-text-muted);min-width:70px;text-align:right; }
.pud-sub { font-weight:600;color:var(--pms-accent-primary);min-width:80px;text-align:right; }
.pu-loading,.pu-skel { background: var(--pms-bg-card);border-radius:14px;padding:16px;margin-bottom:10px; }
</style>
