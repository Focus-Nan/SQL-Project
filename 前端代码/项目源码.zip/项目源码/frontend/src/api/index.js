import request from '../utils/request'

// ============ Auth ============
export function login(employeeNo, password) {
  return request.post('/auth/login', { employeeNo, password })
}

export function register(employeeNo, name, password, phone) {
  return request.post('/auth/register', { employeeNo, name, password, phone })
}

export function getCurrentUser() {
  return request.get('/auth/me')
}

export function uploadAvatar(base64) {
  return request.post('/auth/avatar', { avatar: base64 })
}

// ============ Suppliers ============
export function getSuppliers(search) {
  return request.get('/suppliers', { params: { search } })
}

export function getSupplier(id) {
  return request.get(`/suppliers/${id}`)
}

export function createSupplier(data) {
  return request.post('/suppliers', data)
}

export function batchImportSuppliers(data) {
  return request.post('/suppliers/batch', { data })
}

export function updateSupplier(id, data) {
  return request.put(`/suppliers/${id}`, data)
}

export function deleteSupplier(id) {
  return request.delete(`/suppliers/${id}`)
}

// ============ Products ============
export function getProducts(search) {
  return request.get('/products', { params: { search } })
}

export function getProduct(id) {
  return request.get(`/products/${id}`)
}

export function createProduct(data) {
  return request.post('/products', data)
}

export function batchImportProducts(data) {
  return request.post('/products/batch', { data })
}

export function updateProduct(id, data) {
  return request.put(`/products/${id}`, data)
}

export function deleteProduct(id) {
  return request.delete(`/products/${id}`)
}

// ============ Employees ============
export function getEmployees() {
  return request.get('/employees')
}

export function getEmployee(id) {
  return request.get(`/employees/${id}`)
}

export function createEmployee(data) {
  return request.post('/employees', data)
}

export function batchImportEmployees(data) {
  return request.post('/employees/batch', { data })
}

export function updateEmployee(id, data) {
  return request.put(`/employees/${id}`, data)
}

export function resetEmployeePassword(id, password) {
  return request.put(`/employees/${id}/reset-password`, { password })
}

export function deleteEmployee(id) {
  return request.delete(`/employees/${id}`)
}

// ============ Members ============
export function getMembers(search) {
  return request.get('/members', { params: { search } })
}

export function getMember(id) {
  return request.get(`/members/${id}`)
}

export function createMember(data) {
  return request.post('/members', data)
}

export function batchImportMembers(data) {
  return request.post('/members/batch', { data })
}

export function updateMember(id, data) {
  return request.put(`/members/${id}`, data)
}

export function deleteMember(id) {
  return request.delete(`/members/${id}`)
}

// ============ Purchases ============
export function getPurchaseMains(employeeId) {
  return request.get('/purchases/main', { params: { employeeId } })
}

export function getPurchaseMain(id) {
  return request.get(`/purchases/main/${id}`)
}

export function createPurchaseMain(data) {
  return request.post('/purchases/main', data)
}

export function updatePurchaseMain(id, data) {
  return request.put(`/purchases/main/${id}`, data)
}

export function deletePurchaseMain(id) {
  return request.delete(`/purchases/main/${id}`)
}

export function getPurchaseDetails(mainId) {
  return request.get('/purchases/detail', { params: { mainId } })
}

export function getPurchaseDetail(id) {
  return request.get(`/purchases/detail/${id}`)
}

export function createPurchaseDetail(data) {
  return request.post('/purchases/detail', data)
}

export function updatePurchaseDetail(id, data) {
  return request.put(`/purchases/detail/${id}`, data)
}

export function deletePurchaseDetail(id) {
  return request.delete(`/purchases/detail/${id}`)
}

// ============ Summary / KPI ============
export function getEmployeeKpi() {
  return request.get('/summary/employee-kpi')
}

export function getPurchaseExpenditure() {
  return request.get('/summary/purchase-expenditure')
}

export function getProductDistribution() {
  return request.get('/summary/product-distribution')
}

export function updatePurchaseStatus(id, status) {
  return request.put(`/purchases/main/${id}/status`, { status })
}
