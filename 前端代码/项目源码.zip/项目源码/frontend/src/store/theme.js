import { defineStore } from 'pinia'
import { ref } from 'vue'

export const useThemeStore = defineStore('theme', () => {
  const mode = ref(localStorage.getItem('theme-mode') || 'auto')

  function applyTheme() {
    const mq = window.matchMedia('(prefers-color-scheme: dark)')
    let isDark = false
    if (mode.value === 'dark') isDark = true
    else if (mode.value === 'auto') isDark = mq.matches
    document.documentElement.classList.toggle('dark', isDark)
  }

  function setMode(val) {
    mode.value = val
    localStorage.setItem('theme-mode', val)
    applyTheme()
  }

  function init() {
    applyTheme()
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
      if (mode.value === 'auto') applyTheme()
    })
  }

  return { mode, setMode, applyTheme, init }
})
